import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Edit2, Trash2, DollarSign } from 'lucide-react';
import { Drawer } from 'vaul';

export default function ServiceTypesPage() {
  const queryClient = useQueryClient();
  const [selectedService, setSelectedService] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    seasonal_multiplier: 1.0,
    minimum_price: '',
    minimum_coverage_sqft: 3000,
    price_per_1000sqft: '',
  });

  const { data: serviceTypes, isLoading } = useQuery({
    queryKey: ['service-types'],
    queryFn: async () => {
      const response = await fetch('/api/service-types');
      if (!response.ok) throw new Error('Failed to fetch service types');
      return response.json();
    },
  });

  const addServiceType = useMutation({
    mutationFn: async (newService) => {
      const response = await fetch('/api/service-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newService),
      });
      if (!response.ok) throw new Error('Failed to add service type');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-types']);
      resetForm();
    },
  });

  const updateServiceType = useMutation({
    mutationFn: async ({ id, data }) => {
      const response = await fetch(`/api/service-types/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error('Failed to update service type');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-types']);
      resetForm();
    },
  });

  const deleteServiceType = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/service-types/${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) throw new Error('Failed to delete service type');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['service-types']);
    },
  });

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      seasonal_multiplier: 1.0,
      minimum_price: '',
      minimum_coverage_sqft: 3000,
      price_per_1000sqft: '',
    });
    setSelectedService(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (selectedService) {
        await updateServiceType.mutateAsync({
          id: selectedService.id,
          data: formData,
        });
      } else {
        await addServiceType.mutateAsync(formData);
      }
    } catch (error) {
      console.error('Failed to save service type:', error);
    }
  };

  const handleEdit = (service) => {
    setSelectedService(service);
    setFormData({
      name: service.name,
      description: service.description || '',
      seasonal_multiplier: service.seasonal_multiplier,
      minimum_price: service.minimum_price,
      minimum_coverage_sqft: service.minimum_coverage_sqft,
      price_per_1000sqft: service.price_per_1000sqft,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Service Types</h1>
          <Drawer.Root>
            <Drawer.Trigger asChild>
              <button className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700">
                <Plus size={20} />
                Add Service Type
              </button>
            </Drawer.Trigger>
            <Drawer.Portal>
              <Drawer.Content className="bg-white p-6 rounded-t-[10px] h-[96vh] mt-24 fixed bottom-0 left-0 right-0">
                <div className="max-w-md mx-auto">
                  <Drawer.Title className="text-2xl font-bold mb-6">
                    {selectedService ? 'Edit Service Type' : 'Add New Service Type'}
                  </Drawer.Title>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Service Name
                      </label>
                      <input
                        type="text"
                        required
                        className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                        value={formData.name}
                        onChange={(e) =>
                          setFormData({ ...formData, name: e.target.value })
                        }
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description
                      </label>
                      <textarea
                        className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                        rows="3"
                        value={formData.description}
                        onChange={(e) =>
                          setFormData({ ...formData, description: e.target.value })
                        }
                      ></textarea>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Minimum Price ($)
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          required
                          className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                          value={formData.minimum_price}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              minimum_price: e.target.value,
                            })
                          }
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Price per 1000 sq ft ($)
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          required
                          className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                          value={formData.price_per_1000sqft}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              price_per_1000sqft: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Minimum Coverage (sq ft)
                        </label>
                        <input
                          type="number"
                          required
                          className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                          value={formData.minimum_coverage_sqft}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              minimum_coverage_sqft: e.target.value,
                            })
                          }
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Seasonal Multiplier
                        </label>
                        <input
                          type="number"
                          step="0.01"
                          min="0.1"
                          max="5"
                          required
                          className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                          value={formData.seasonal_multiplier}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              seasonal_multiplier: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-4 mt-6">
                      <Drawer.Close
                        className="px-4 py-2 border rounded-lg hover:bg-gray-50"
                        onClick={resetForm}
                      >
                        Cancel
                      </Drawer.Close>
                      <button
                        type="submit"
                        className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                      >
                        {selectedService ? 'Update' : 'Add'} Service Type
                      </button>
                    </div>
                  </form>
                </div>
              </Drawer.Content>
              <Drawer.Overlay className="fixed inset-0 bg-black/40" />
            </Drawer.Portal>
          </Drawer.Root>
        </div>

        <div className="bg-white rounded-lg shadow-md">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th className="text-left py-3 px-4">Service Name</th>
                  <th className="text-left py-3 px-4">Base Pricing</th>
                  <th className="text-left py-3 px-4">Coverage</th>
                  <th className="text-left py-3 px-4">Seasonal Multiplier</th>
                  <th className="text-right py-3 px-4">Actions</th>
                </tr>
              </thead>
              <tbody>
                {serviceTypes?.map((service) => (
                  <tr key={service.id} className="border-t">
                    <td className="py-3 px-4">
                      <div>
                        <div className="font-medium">{service.name}</div>
                        {service.description && (
                          <div className="text-sm text-gray-500">
                            {service.description}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <DollarSign size={16} className="text-gray-400" />
                        <span>{service.minimum_price}</span>
                        <span className="text-gray-500">min</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        ${service.price_per_1000sqft}/1000 sq ft
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div>
                        <span>{service.minimum_coverage_sqft.toLocaleString()}</span>
                        <span className="text-gray-500"> sq ft min</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-medium">
                        {service.seasonal_multiplier}x
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <div className="flex justify-end gap-2">
                        <Drawer.Trigger asChild>
                          <button
                            onClick={() => handleEdit(service)}
                            className="p-2 hover:bg-gray-100 rounded-lg"
                            title="Edit"
                          >
                            <Edit2 size={18} className="text-gray-600" />
                          </button>
                        </Drawer.Trigger>
                        <button
                          onClick={() => {
                            if (
                              window.confirm(
                                'Are you sure you want to delete this service type?'
                              )
                            ) {
                              deleteServiceType.mutate(service.id);
                            }
                          }}
                          className="p-2 hover:bg-gray-100 rounded-lg"
                          title="Delete"
                        >
                          <Trash2 size={18} className="text-red-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}