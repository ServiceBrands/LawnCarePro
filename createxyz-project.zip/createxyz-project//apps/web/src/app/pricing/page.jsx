import { useState } from 'react';
import { Calculator, DollarSign, Ruler, Map } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

export default function PricingCalculatorPage() {
  const [formData, setFormData] = useState({
    service_type_id: '',
    property_size_sqft: '',
    zip_code: '',
    terrain_difficulty: 'normal',
  });

  const [quote, setQuote] = useState(null);
  const [error, setError] = useState(null);
  const [calculating, setCalculating] = useState(false);

  const { data: serviceTypes } = useQuery({
    queryKey: ['service-types'],
    queryFn: async () => {
      const response = await fetch('/api/service-types');
      if (!response.ok) throw new Error('Failed to fetch service types');
      return response.json();
    },
  });

  const calculatePrice = async (e) => {
    e.preventDefault();
    setCalculating(true);
    setError(null);

    try {
      const response = await fetch('/api/pricing/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to calculate price');
      }

      const data = await response.json();
      setQuote(data);
    } catch (err) {
      console.error('Calculation error:', err);
      setError('Failed to calculate price. Please try again.');
    } finally {
      setCalculating(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Pricing Calculator</h1>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-6">Calculate Service Price</h2>
            <form onSubmit={calculatePrice} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Service Type
                </label>
                <select
                  required
                  className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                  value={formData.service_type_id}
                  onChange={(e) =>
                    setFormData({ ...formData, service_type_id: e.target.value })
                  }
                >
                  <option value="">Select a service</option>
                  {serviceTypes?.map((service) => (
                    <option key={service.id} value={service.id}>
                      {service.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Property Size (sq ft)
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                  value={formData.property_size_sqft}
                  onChange={(e) =>
                    setFormData({ ...formData, property_size_sqft: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  ZIP Code
                </label>
                <input
                  type="text"
                  required
                  pattern="[0-9]{5}"
                  className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                  value={formData.zip_code}
                  onChange={(e) =>
                    setFormData({ ...formData, zip_code: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Terrain Difficulty
                </label>
                <select
                  className="w-full rounded-lg border-gray-300 focus:border-green-500 focus:ring-green-500"
                  value={formData.terrain_difficulty}
                  onChange={(e) =>
                    setFormData({ ...formData, terrain_difficulty: e.target.value })
                  }
                >
                  <option value="easy">Easy</option>
                  <option value="normal">Normal</option>
                  <option value="difficult">Difficult</option>
                </select>
              </div>

              {error && (
                <div className="text-red-600 text-sm">{error}</div>
              )}

              <button
                type="submit"
                disabled={calculating}
                className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 disabled:opacity-50"
              >
                {calculating ? (
                  <div className="flex items-center justify-center gap-2">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    <span>Calculating...</span>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Calculator size={20} />
                    <span>Calculate Price</span>
                  </div>
                )}
              </button>
            </form>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-6">Price Breakdown</h2>
            {!quote ? (
              <div className="text-center text-gray-500 py-8">
                <Calculator className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Enter service details to see the price breakdown</p>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b">
                  <div className="flex items-center gap-2">
                    <DollarSign className="text-green-600" size={20} />
                    <span className="font-medium">Total Cost</span>
                  </div>
                  <span className="text-2xl font-bold">
                    ${quote.total_cost.toFixed(2)}
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Labor Cost</span>
                    <span className="font-medium">${quote.labor_cost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Material Cost</span>
                    <span className="font-medium">${quote.material_cost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Equipment Cost</span>
                    <span className="font-medium">${quote.equipment_cost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Overhead Cost</span>
                    <span className="font-medium">${quote.overhead_cost.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center text-green-600">
                    <span>Profit Margin</span>
                    <span className="font-medium">{(quote.profit_margin * 100).toFixed(1)}%</span>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <div className="flex items-center gap-2 text-gray-600 mb-2">
                    <Ruler size={16} />
                    <span>Property Size: {quote.property_size_sqft} sq ft</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Map size={16} />
                    <span>Regional Cost Adjustment Applied</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}