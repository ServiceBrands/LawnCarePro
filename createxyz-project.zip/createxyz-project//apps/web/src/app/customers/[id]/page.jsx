import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Calendar, Mail, Phone, MessageSquare, Clock, Send, Edit2, Tag, Plus } from 'lucide-react';
import { format } from 'date-fns';

export default function CustomerDetailPage({ params }) {
  const { id } = params;
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('overview');

  const { data: customer, isLoading: customerLoading } = useQuery({
    queryKey: ['customer', id],
    queryFn: async () => {
      const response = await fetch(`/api/customers/${id}`);
      if (!response.ok) throw new Error('Failed to fetch customer');
      return response.json();
    }
  });

  const { data: interactions, isLoading: interactionsLoading } = useQuery({
    queryKey: ['customer-interactions', id],
    queryFn: async () => {
      const response = await fetch(`/api/customers/${id}/interactions`);
      if (!response.ok) throw new Error('Failed to fetch interactions');
      return response.json();
    }
  });

  const { data: communications, isLoading: communicationsLoading } = useQuery({
    queryKey: ['customer-communications', id],
    queryFn: async () => {
      const response = await fetch(`/api/customers/${id}/communications`);
      if (!response.ok) throw new Error('Failed to fetch communications');
      return response.json();
    }
  });

  const updateCustomer = useMutation({
    mutationFn: async (updates) => {
      const response = await fetch(`/api/customers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates)
      });
      if (!response.ok) throw new Error('Failed to update customer');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['customer', id]);
    }
  });

  if (customerLoading || interactionsLoading || communicationsLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-md">
        {/* Customer Header */}
        <div className="p-6 border-b">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h1 className="text-2xl font-bold mb-2">{customer.name}</h1>
              <div className="flex items-center gap-4 text-gray-600">
                <div className="flex items-center gap-2">
                  <Mail size={16} />
                  <span>{customer.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={16} />
                  <span>{customer.phone}</span>
                </div>
              </div>
            </div>
            <button
              onClick={() => {/* Edit customer modal logic */}}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <Edit2 size={20} className="text-gray-600" />
            </button>
          </div>

          <div className="flex items-center gap-4">
            <span className={`px-3 py-1 rounded-full text-sm ${
              customer.status === 'lead' ? 'bg-yellow-100 text-yellow-800' :
              customer.status === 'active' ? 'bg-green-100 text-green-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {customer.status || 'lead'}
            </span>
            {customer.tags?.map((tag, index) => (
              <span key={index} className="flex items-center gap-1 px-3 py-1 bg-gray-100 rounded-full text-sm">
                <Tag size={14} />
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b px-6">
          <div className="flex gap-6">
            {['overview', 'interactions', 'communications', 'quotes'].map((tab) => (
              <button
                key={tab}
                className={`py-4 px-2 border-b-2 font-medium ${
                  activeTab === tab
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab(tab)}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Content Area */}
        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-4">Property Details</h3>
                <div className="space-y-2">
                  <p><span className="text-gray-600">Size:</span> {customer.property_size_sqft} sq ft</p>
                  <p><span className="text-gray-600">Grass Type:</span> {customer.grass_type}</p>
                  <p><span className="text-gray-600">Terrain:</span> {customer.terrain_difficulty}</p>
                </div>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium mb-4">Contact History</h3>
                <div className="space-y-2">
                  <p><span className="text-gray-600">Last Contact:</span> {customer.last_contact_date ? format(new Date(customer.last_contact_date), 'MMM d, yyyy') : 'Never'}</p>
                  <p><span className="text-gray-600">Next Follow-up:</span> {customer.next_follow_up_date ? format(new Date(customer.next_follow_up_date), 'MMM d, yyyy') : 'Not scheduled'}</p>
                  <p><span className="text-gray-600">Customer Since:</span> {customer.customer_since ? format(new Date(customer.customer_since), 'MMM d, yyyy') : 'N/A'}</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'interactions' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-medium">Recent Interactions</h3>
                <button
                  onClick={() => {/* Add interaction modal logic */}}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                >
                  <MessageSquare size={20} />
                  Add Interaction
                </button>
              </div>
              {interactions?.map((interaction) => (
                <div key={interaction.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium">{interaction.interaction_type}</span>
                    <span className="text-sm text-gray-500">{format(new Date(interaction.interaction_date), 'MMM d, yyyy')}</span>
                  </div>
                  <p className="text-gray-600 mb-2">{interaction.notes}</p>
                  {interaction.follow_up_needed && (
                    <div className="flex items-center gap-2 text-sm text-orange-600">
                      <Calendar size={16} />
                      <span>Follow-up needed by {format(new Date(interaction.follow_up_date), 'MMM d, yyyy')}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'communications' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-medium">Communication History</h3>
                <button
                  onClick={() => {/* Send communication modal logic */}}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                >
                  <Send size={20} />
                  Send Message
                </button>
              </div>
              {communications?.map((comm) => (
                <div key={comm.id} className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <span className="font-medium">{comm.subject}</span>
                    <span className="text-sm text-gray-500">{format(new Date(comm.sent_at), 'MMM d, yyyy')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-2">
                    <span>{comm.communication_type}</span>
                    <span>•</span>
                    <span>{comm.email_address || comm.phone_number}</span>
                  </div>
                  <p className="text-gray-600">{comm.content}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'quotes' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-medium">Quotes</h3>
                <button
                  onClick={() => {/* Create quote modal logic */}}
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700"
                >
                  <Plus size={20} />
                  Create Quote
                </button>
              </div>
              {/* Quotes list will be implemented in the next iteration */}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}