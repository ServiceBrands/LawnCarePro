import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Calendar,
  Mail,
  Phone,
  Plus,
  Search,
  Tag,
  UserPlus,
  Clock,
  MessageSquare,
} from "lucide-react";
import { format } from "date-fns";
import { Drawer } from "vaul";

export default function CustomersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const queryClient = useQueryClient();

  // Form states
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    property_size_sqft: "",
    grass_type: "",
    terrain_difficulty: "normal",
    accessibility_notes: "",
  });

  const [newInteraction, setNewInteraction] = useState({
    interaction_type: "call",
    notes: "",
    follow_up_needed: false,
    follow_up_date: "",
  });

  const { data: customers, isLoading } = useQuery({
    queryKey: ["customers", searchTerm],
    queryFn: async () => {
      const response = await fetch(
        `/api/customers${searchTerm ? `?search=${encodeURIComponent(searchTerm)}` : ""}`,
      );
      if (!response.ok) throw new Error("Failed to fetch customers");
      return response.json();
    },
  });

  const addCustomer = useMutation({
    mutationFn: async (newCustomer) => {
      const response = await fetch("/api/customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCustomer),
      });
      if (!response.ok) throw new Error("Failed to add customer");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["customers"]);
    },
  });

  const addInteraction = useMutation({
    mutationFn: async ({ customerId, interaction }) => {
      const response = await fetch(
        `/api/customers/${customerId}/interactions`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(interaction),
        },
      );
      if (!response.ok) throw new Error("Failed to add interaction");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["customers"]);
    },
  });

  const sendCommunication = useMutation({
    mutationFn: async ({ customerId, communication }) => {
      const response = await fetch(
        `/api/customers/${customerId}/communications`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(communication),
        },
      );
      if (!response.ok) throw new Error("Failed to send communication");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries(["customers"]);
    },
  });

  const handleAddCustomer = async (e) => {
    e.preventDefault();
    try {
      await addCustomer.mutateAsync(newCustomer);
      setNewCustomer({
        name: "",
        email: "",
        phone: "",
        address: "",
        city: "",
        state: "",
        zip_code: "",
        property_size_sqft: "",
        grass_type: "",
        terrain_difficulty: "normal",
        accessibility_notes: "",
      });
    } catch (error) {
      console.error("Failed to add customer:", error);
    }
  };

  const handleAddInteraction = async (e) => {
    e.preventDefault();
    if (!selectedCustomer) return;

    try {
      await addInteraction.mutateAsync({
        customerId: selectedCustomer.id,
        interaction: newInteraction,
      });
      setNewInteraction({
        interaction_type: "call",
        notes: "",
        follow_up_needed: false,
        follow_up_date: "",
      });
    } catch (error) {
      console.error("Failed to add interaction:", error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Customer Management</h1>
        <button
          onClick={() => {
            /* Add new customer modal logic */
          }}
          className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700"
        >
          <UserPlus size={20} />
          Add Customer
        </button>
      </div>

      {/* Add Customer Drawer */}
      <Drawer.Root>
        <Drawer.Trigger asChild>
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-green-700">
            <UserPlus size={20} />
            Add Customer
          </button>
        </Drawer.Trigger>
        <Drawer.Portal>
          <Drawer.Content className="bg-white p-6 rounded-t-[10px] h-[96vh] mt-24 fixed bottom-0 left-0 right-0">
            <div className="max-w-md mx-auto">
              <Drawer.Title className="text-2xl font-bold mb-6">
                Add New Customer
              </Drawer.Title>
              <form onSubmit={handleAddCustomer} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Name
                  </label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    value={newCustomer.name}
                    onChange={(e) =>
                      setNewCustomer({ ...newCustomer, name: e.target.value })
                    }
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <input
                      type="email"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.email}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          email: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Phone
                    </label>
                    <input
                      type="tel"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.phone}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          phone: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Address
                  </label>
                  <input
                    type="text"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    value={newCustomer.address}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        address: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      City
                    </label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.city}
                      onChange={(e) =>
                        setNewCustomer({ ...newCustomer, city: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      State
                    </label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.state}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          state: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      ZIP Code
                    </label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.zip_code}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          zip_code: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Property Size (sq ft)
                    </label>
                    <input
                      type="number"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.property_size_sqft}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          property_size_sqft: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Grass Type
                    </label>
                    <input
                      type="text"
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                      value={newCustomer.grass_type}
                      onChange={(e) =>
                        setNewCustomer({
                          ...newCustomer,
                          grass_type: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Terrain Difficulty
                  </label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    value={newCustomer.terrain_difficulty}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        terrain_difficulty: e.target.value,
                      })
                    }
                  >
                    <option value="easy">Easy</option>
                    <option value="normal">Normal</option>
                    <option value="difficult">Difficult</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Accessibility Notes
                  </label>
                  <textarea
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    rows="3"
                    value={newCustomer.accessibility_notes}
                    onChange={(e) =>
                      setNewCustomer({
                        ...newCustomer,
                        accessibility_notes: e.target.value,
                      })
                    }
                  ></textarea>
                </div>
                <div className="flex justify-end gap-4">
                  <Drawer.Close className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                    Cancel
                  </Drawer.Close>
                  <button
                    type="submit"
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                  >
                    Add Customer
                  </button>
                </div>
              </form>
            </div>
          </Drawer.Content>
          <Drawer.Overlay className="fixed inset-0 bg-black/40" />
        </Drawer.Portal>
      </Drawer.Root>

      {/* Add Interaction Drawer */}
      <Drawer.Root>
        <Drawer.Content className="bg-white p-6 rounded-t-[10px] h-[96vh] mt-24 fixed bottom-0 left-0 right-0">
          <div className="max-w-md mx-auto">
            <Drawer.Title className="text-2xl font-bold mb-6">
              Add Interaction
            </Drawer.Title>
            <form onSubmit={handleAddInteraction} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Type
                </label>
                <select
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  value={newInteraction.interaction_type}
                  onChange={(e) =>
                    setNewInteraction({
                      ...newInteraction,
                      interaction_type: e.target.value,
                    })
                  }
                >
                  <option value="call">Call</option>
                  <option value="email">Email</option>
                  <option value="meeting">Meeting</option>
                  <option value="site_visit">Site Visit</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Notes
                </label>
                <textarea
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  rows="3"
                  value={newInteraction.notes}
                  onChange={(e) =>
                    setNewInteraction({
                      ...newInteraction,
                      notes: e.target.value,
                    })
                  }
                ></textarea>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="follow_up_needed"
                  checked={newInteraction.follow_up_needed}
                  onChange={(e) =>
                    setNewInteraction({
                      ...newInteraction,
                      follow_up_needed: e.target.checked,
                    })
                  }
                  className="rounded border-gray-300 text-green-600 focus:ring-green-500"
                />
                <label
                  htmlFor="follow_up_needed"
                  className="text-sm font-medium text-gray-700"
                >
                  Follow-up needed?
                </label>
              </div>
              {newInteraction.follow_up_needed && (
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Follow-up Date
                  </label>
                  <input
                    type="date"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                    value={newInteraction.follow_up_date}
                    onChange={(e) =>
                      setNewInteraction({
                        ...newInteraction,
                        follow_up_date: e.target.value,
                      })
                    }
                  />
                </div>
              )}
              <div className="flex justify-end gap-4">
                <Drawer.Close className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                  Cancel
                </Drawer.Close>
                <button
                  type="submit"
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                >
                  Add Interaction
                </button>
              </div>
            </form>
          </div>
        </Drawer.Content>
        <Drawer.Overlay className="fixed inset-0 bg-black/40" />
      </Drawer.Root>

      {/* Customer History Drawer */}
      <Drawer.Root>
        <Drawer.Content className="bg-white p-6 rounded-t-[10px] h-[96vh] mt-24 fixed bottom-0 left-0 right-0">
          <div className="max-w-2xl mx-auto">
            <Drawer.Title className="text-2xl font-bold mb-6">
              Customer History
            </Drawer.Title>
            {selectedCustomer && (
              <div className="space-y-6">
                <div className="border-b pb-4">
                  <h3 className="text-lg font-semibold mb-2">
                    Customer Information
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Name</p>
                      <p className="font-medium">{selectedCustomer.name}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      <p className="font-medium capitalize">
                        {selectedCustomer.status}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Email</p>
                      <p className="font-medium">{selectedCustomer.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Phone</p>
                      <p className="font-medium">{selectedCustomer.phone}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">
                    Interaction History
                  </h3>
                  <div className="space-y-4">
                    {selectedCustomer.interactions?.map((interaction) => (
                      <div
                        key={interaction.id}
                        className="bg-gray-50 p-4 rounded-lg"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <span className="font-medium capitalize">
                              {interaction.interaction_type}
                            </span>
                            <span className="text-sm text-gray-500 ml-2">
                              {format(
                                new Date(interaction.interaction_date),
                                "MMM d, yyyy",
                              )}
                            </span>
                          </div>
                          {interaction.follow_up_needed && (
                            <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                              Follow-up:{" "}
                              {format(
                                new Date(interaction.follow_up_date),
                                "MMM d, yyyy",
                              )}
                            </span>
                          )}
                        </div>
                        <p className="text-gray-600">{interaction.notes}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div className="mt-6 flex justify-end">
              <Drawer.Close className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                Close
              </Drawer.Close>
            </div>
          </div>
        </Drawer.Content>
        <Drawer.Overlay className="fixed inset-0 bg-black/40" />
      </Drawer.Root>

      <div className="bg-white rounded-lg shadow-md p-6 mb-6">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 relative">
            <Search
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
              size={20}
            />
            <input
              type="text"
              placeholder="Search customers..."
              className="w-full pl-10 pr-4 py-2 border rounded-lg"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button className="px-4 py-2 border rounded-lg flex items-center gap-2 hover:bg-gray-50">
            <Plus size={20} />
            Add Filter
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left py-3 px-4">Customer</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-left py-3 px-4">Contact Info</th>
                <th className="text-left py-3 px-4">Last Contact</th>
                <th className="text-left py-3 px-4">Next Follow-up</th>
                <th className="text-left py-3 px-4">Actions</th>
              </tr>
            </thead>
            <tbody>
              {customers?.map((customer) => (
                <tr key={customer.id} className="border-b hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <div className="flex flex-col">
                      <span className="font-medium">{customer.name}</span>
                      <span className="text-sm text-gray-500">
                        {customer.address}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span
                      className={`px-2 py-1 rounded-full text-sm ${
                        customer.status === "lead"
                          ? "bg-yellow-100 text-yellow-800"
                          : customer.status === "active"
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {customer.status || "lead"}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-2">
                        <Mail size={16} className="text-gray-400" />
                        <span className="text-sm">{customer.email}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Phone size={16} className="text-gray-400" />
                        <span className="text-sm">{customer.phone}</span>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-sm">
                      {customer.last_contact_date
                        ? format(
                            new Date(customer.last_contact_date),
                            "MMM d, yyyy",
                          )
                        : "Never"}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-sm">
                      {customer.next_follow_up_date
                        ? format(
                            new Date(customer.next_follow_up_date),
                            "MMM d, yyyy",
                          )
                        : "Not scheduled"}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex gap-2">
                      <Drawer.Trigger asChild>
                        <button
                          onClick={() => setSelectedCustomer(customer)}
                          className="p-2 hover:bg-gray-100 rounded-lg"
                          title="Add Interaction"
                        >
                          <MessageSquare size={20} className="text-gray-600" />
                        </button>
                      </Drawer.Trigger>
                      <button
                        onClick={() => {
                          setSelectedCustomer(customer);
                          setNewInteraction({
                            ...newInteraction,
                            follow_up_needed: true,
                            follow_up_date: format(
                              new Date().setDate(new Date().getDate() + 7),
                              "yyyy-MM-dd",
                            ),
                          });
                        }}
                        className="p-2 hover:bg-gray-100 rounded-lg"
                        title="Schedule Follow-up"
                      >
                        <Calendar size={20} className="text-gray-600" />
                      </button>
                      <Drawer.Trigger asChild>
                        <button
                          onClick={() => setSelectedCustomer(customer)}
                          className="p-2 hover:bg-gray-100 rounded-lg"
                          title="View History"
                        >
                          <Clock size={20} className="text-gray-600" />
                        </button>
                      </Drawer.Trigger>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
