import { Calculator, Camera, Users, Settings, Bug } from "lucide-react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// Create a client with the same configuration as mobile
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <QueryClientProvider client={queryClient}>
          <div className="min-h-screen flex">
            {/* Sidebar Navigation */}
            <nav className="bg-white w-64 border-r flex-shrink-0 hidden md:block">
              <div className="p-4 border-b">
                <div className="flex items-center">
                  <div className="bg-green-600 p-2 rounded-lg">
                    <Bug className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-3">
                    <h1 className="text-lg font-bold text-gray-900">
                      Lawn Care Pro
                    </h1>
                    <p className="text-xs text-gray-600">Business Management</p>
                  </div>
                </div>
              </div>
              <div className="p-4">
                <nav className="space-y-2">
                  <a
                    href="/"
                    className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                  >
                    <Calculator className="h-5 w-5 mr-3" />
                    Pricing Calculator
                  </a>
                  <a
                    href="/pest-identification"
                    className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                  >
                    <Camera className="h-5 w-5 mr-3" />
                    Pest Identification
                  </a>
                  <a
                    href="/customers"
                    className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                  >
                    <Users className="h-5 w-5 mr-3" />
                    Customer CRM
                  </a>
                  <a
                    href="/settings"
                    className="flex items-center px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                  >
                    <Settings className="h-5 w-5 mr-3" />
                    Settings
                  </a>
                </nav>
              </div>
            </nav>

            {/* Mobile Header */}
            <div className="md:hidden bg-white border-b w-full">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-center">
                  <div className="bg-green-600 p-2 rounded-lg">
                    <Bug className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-3">
                    <h1 className="text-lg font-bold text-gray-900">
                      Lawn Care Pro
                    </h1>
                  </div>
                </div>
                {/* Mobile menu button */}
                <button className="p-2 rounded-lg hover:bg-gray-100">
                  <svg
                    className="h-6 w-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </button>
              </div>
            </div>

            {/* Main Content */}
            <main className="flex-1 bg-gray-50">{children}</main>
          </div>
        </QueryClientProvider>
      </body>
    </html>
  );
}
