import React, { useEffect, useState } from "react";
import {
  Calculator,
  Camera,
  Users,
  Settings,
  Smartphone,
  Globe,
  DollarSign,
  Bug,
  CheckCircle,
} from "lucide-react";

export default function HomePage() {
  const [qrCode, setQrCode] = useState("");
  const appStoreUrl = null; // TODO: Add your app store URL when available

  // Only generate QR code when we have a valid URL
  useEffect(() => {
    if (appStoreUrl) {
      fetch(
        `/integrations/qr-code/generatebasicbase64?data=${encodeURIComponent(appStoreUrl)}&size=200`,
      )
        .then((response) => response.text())
        .then((data) => setQrCode(data))
        .catch((error) => console.error("Error generating QR code:", error));
    }
  }, [appStoreUrl]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="bg-green-600 p-2 rounded-lg">
                <Bug className="h-8 w-8 text-white" />
              </div>
              <div className="ml-3">
                <h1 className="text-2xl font-bold text-gray-900">
                  Lawn Care Pro
                </h1>
                <p className="text-sm text-gray-600">
                  Complete Business Management
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-green-100 px-3 py-1 rounded-full">
                <span className="text-green-800 text-sm font-medium">
                  v1.1.0
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            Professional Lawn Care
            <span className="text-green-600 block">Business Management</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Manage your entire lawn care business - from customer relationships
            and pricing to pest identification and quotes - all in one
            comprehensive platform designed specifically for lawn care
            professionals.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <div className="bg-green-600 text-white px-8 py-3 rounded-lg font-semibold flex items-center">
              <Smartphone className="h-5 w-5 mr-2" />
              Mobile App Available
            </div>
            <div className="bg-white text-green-600 border-2 border-green-600 px-8 py-3 rounded-lg font-semibold flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Web Dashboard
            </div>
          </div>

          {/* QR Code Section */}
          <div className="mt-12 flex flex-col items-center">
            <p className="text-lg text-gray-700 mb-4">Mobile App Coming Soon</p>
            <div className="bg-white p-6 rounded-xl shadow-lg text-center">
              <p className="text-gray-600">
                Our mobile app is currently in development. Check back soon to
                download from the App Store!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need to Run Your Business
            </h3>
            <p className="text-lg text-gray-600">
              Powerful tools designed specifically for lawn care professionals
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Pricing Calculator */}
            <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl">
              <div className="bg-green-600 p-3 rounded-lg w-fit mb-4">
                <Calculator className="h-6 w-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Pricing Calculator
              </h4>
              <p className="text-gray-600 mb-4">
                Calculate accurate pricing with labor, materials, equipment
                costs, and regional adjustments.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Service type selection</li>
                <li>• Terrain difficulty factors</li>
                <li>• Regional pricing data</li>
                <li>• Profit margin optimization</li>
              </ul>
            </div>

            {/* Pest Identification */}
            <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl">
              <div className="bg-blue-600 p-3 rounded-lg w-fit mb-4">
                <Camera className="h-6 w-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                AI Pest & Weed ID
              </h4>
              <p className="text-gray-600 mb-4">
                Take photos to identify pests, diseases, and weeds with
                AI-powered analysis.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Photo-based identification</li>
                <li>• Treatment recommendations</li>
                <li>• Severity assessment</li>
                <li>• Cost estimation</li>
              </ul>
            </div>

            {/* Customer Management */}
            <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl">
              <div className="bg-purple-600 p-3 rounded-lg w-fit mb-4">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Customer CRM
              </h4>
              <p className="text-gray-600 mb-4">
                Complete customer relationship management with communication
                tracking and follow-ups.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Contact management</li>
                <li>• Interaction tracking</li>
                <li>• Follow-up reminders</li>
                <li>• Communication history</li>
              </ul>
            </div>

            {/* Business Settings */}
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl">
              <div className="bg-orange-600 p-3 rounded-lg w-fit mb-4">
                <Settings className="h-6 w-6 text-white" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Business Settings
              </h4>
              <p className="text-gray-600 mb-4">
                Configure your business information and pricing defaults.
              </p>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Business information</li>
                <li>• Default pricing rates</li>
                <li>• Operating costs</li>
                <li>• Profit margins</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Why Lawn Care Professionals Choose Our App
            </h3>
            <p className="text-lg text-gray-600">
              Built specifically for the lawn care industry
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <DollarSign className="h-8 w-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Accurate Pricing
              </h4>
              <p className="text-gray-600">
                Never undercharge again. Our calculator considers all costs
                including labor, materials, equipment, overhead, and regional
                pricing variations.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Bug className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Expert Identification
              </h4>
              <p className="text-gray-600">
                Identify lawn problems instantly with AI. Get treatment
                recommendations, timing advice, and cost estimates for pest and
                weed control.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-purple-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <CheckCircle className="h-8 w-8 text-purple-600" />
              </div>
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Professional Results
              </h4>
              <p className="text-gray-600">
                Generate professional quotes, maintain detailed customer
                records, and provide expert service recommendations to grow your
                business.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Tiers */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              Simple, Transparent Pricing
            </h3>
            <p className="text-lg text-gray-600">
              Choose the plan that fits your business needs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* Basic Plan */}
            <div className="bg-gray-50 p-8 rounded-xl">
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Basic
              </h4>
              <div className="text-3xl font-bold text-gray-900 mb-4">Free</div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Basic pricing calculator
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />5 pest
                  identifications/month
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Up to 10 customers
                </li>
              </ul>
              <button className="w-full bg-gray-200 text-gray-800 py-3 rounded-lg font-semibold">
                Get Started
              </button>
            </div>

            {/* Professional Plan */}
            <div className="bg-green-600 p-8 rounded-xl text-white relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  Most Popular
                </span>
              </div>
              <h4 className="text-xl font-semibold mb-2">Professional</h4>
              <div className="text-3xl font-bold mb-4">
                $29<span className="text-lg">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-200 mr-2" />
                  Advanced pricing calculator
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-200 mr-2" />
                  Unlimited pest identifications
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-200 mr-2" />
                  Unlimited customers
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-200 mr-2" />
                  Professional quote generation
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-200 mr-2" />
                  Regional pricing data
                </li>
              </ul>
              <button className="w-full bg-white text-green-600 py-3 rounded-lg font-semibold">
                Start Free Trial
              </button>
            </div>

            {/* Enterprise Plan */}
            <div className="bg-gray-50 p-8 rounded-xl">
              <h4 className="text-xl font-semibold text-gray-900 mb-2">
                Enterprise
              </h4>
              <div className="text-3xl font-bold text-gray-900 mb-4">
                $99<span className="text-lg">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Everything in Professional
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Multi-user access
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Advanced reporting
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  API access
                </li>
                <li className="flex items-center text-gray-600">
                  <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                  Priority support
                </li>
              </ul>
              <button className="w-full bg-gray-200 text-gray-800 py-3 rounded-lg font-semibold">
                Contact Sales
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <div className="bg-green-600 p-2 rounded-lg">
                  <Bug className="h-6 w-6 text-white" />
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-bold">Lawn Care Pro</h3>
                </div>
              </div>
              <p className="text-gray-400">
                Professional lawn care business management tools for pricing,
                pest identification, and customer management.
              </p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Pricing Calculator</li>
                <li>Pest Identification</li>
                <li>Customer Management</li>
                <li>Quote Generation</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Documentation</li>
                <li>Help Center</li>
                <li>Contact Support</li>
                <li>Feature Requests</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li>About Us</li>
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
                <li>Contact</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>
              &copy; 2025 Lawn Care Pro. All rights reserved. Built for lawn
              care professionals.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
