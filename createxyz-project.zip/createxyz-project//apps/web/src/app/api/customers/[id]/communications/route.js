import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const result = await sql`
      SELECT 
        cc.*,
        au.name as created_by_name
      FROM customer_communications cc
      LEFT JOIN auth_users au ON cc.created_by = au.id
      WHERE customer_id = ${id}
      ORDER BY sent_at DESC
    `;
    return Response.json(result);
  } catch (error) {
    console.error('Error fetching customer communications:', error);
    return Response.json({ error: 'Failed to fetch customer communications' }, { status: 500 });
  }
}

export async function POST(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const {
      quote_id,
      communication_type,
      subject,
      content,
      email_address,
      phone_number
    } = body;

    if (!communication_type || (!email_address && !phone_number)) {
      return Response.json({ error: 'Communication type and either email or phone is required' }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO customer_communications (
        customer_id,
        quote_id,
        communication_type,
        subject,
        content,
        email_address,
        phone_number,
        created_by,
        status
      ) VALUES (
        ${id},
        ${quote_id},
        ${communication_type},
        ${subject},
        ${content},
        ${email_address},
        ${phone_number},
        ${session.user.id},
        'sent'
      ) RETURNING *
    `;

    // Update customer's last contact date
    await sql`
      UPDATE customers 
      SET last_contact_date = CURRENT_TIMESTAMP
      WHERE id = ${id}
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error creating customer communication:', error);
    return Response.json({ error: 'Failed to create customer communication' }, { status: 500 });
  }
}