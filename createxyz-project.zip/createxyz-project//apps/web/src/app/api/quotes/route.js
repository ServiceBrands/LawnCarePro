import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const customerId = searchParams.get('customerId');
    
    let query = `
      SELECT q.*, c.name as customer_name, s.name as service_name
      FROM quotes q
      LEFT JOIN customers c ON q.customer_id = c.id
      LEFT JOIN service_types s ON q.service_type_id = s.id
    `;
    let params = [];
    
    if (customerId) {
      query += ' WHERE q.customer_id = $1';
      params = [customerId];
    }
    
    query += ' ORDER BY q.created_at DESC';
    
    const quotes = await sql(query, params);
    return Response.json(quotes);
  } catch (error) {
    console.error('Error fetching quotes:', error);
    return Response.json({ error: 'Failed to fetch quotes' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      customerId,
      serviceTypeId,
      propertySizeSqft,
      laborHours,
      laborCost,
      materialCost,
      equipmentCost,
      overheadCost,
      profitMargin,
      totalCost,
      notes,
      validDays = 30
    } = body;

    if (!customerId || !serviceTypeId || !totalCost) {
      return Response.json({ 
        error: 'Customer ID, service type, and total cost are required' 
      }, { status: 400 });
    }

    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + validDays);

    const result = await sql`
      INSERT INTO quotes (
        customer_id, service_type_id, property_size_sqft, labor_hours,
        labor_cost, material_cost, equipment_cost, overhead_cost,
        profit_margin, total_cost, notes, valid_until
      ) VALUES (
        ${customerId}, ${serviceTypeId}, ${propertySizeSqft}, ${laborHours},
        ${laborCost}, ${materialCost}, ${equipmentCost}, ${overheadCost},
        ${profitMargin}, ${totalCost}, ${notes}, ${validUntil}
      ) RETURNING *
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error creating quote:', error);
    return Response.json({ error: 'Failed to create quote' }, { status: 500 });
  }
}