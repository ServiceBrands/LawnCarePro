import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request, { params }) {
  try {
    const { id } = params;
    const result = await sql`
      SELECT 
        ci.*,
        au.name as created_by_name
      FROM customer_interactions ci
      LEFT JOIN auth_users au ON ci.created_by = au.id
      WHERE customer_id = ${id}
      ORDER BY interaction_date DESC
    `;
    return Response.json(result);
  } catch (error) {
    console.error('Error fetching customer interactions:', error);
    return Response.json({ error: 'Failed to fetch customer interactions' }, { status: 500 });
  }
}

export async function POST(request, { params }) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = params;
    const body = await request.json();
    const {
      interaction_type,
      notes,
      follow_up_needed,
      follow_up_date
    } = body;

    if (!interaction_type) {
      return Response.json({ error: 'Interaction type is required' }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO customer_interactions (
        customer_id,
        interaction_type,
        notes,
        follow_up_needed,
        follow_up_date,
        created_by
      ) VALUES (
        ${id},
        ${interaction_type},
        ${notes},
        ${follow_up_needed},
        ${follow_up_date},
        ${session.user.id}
      ) RETURNING *
    `;

    // Update customer's last contact date
    await sql`
      UPDATE customers 
      SET last_contact_date = CURRENT_TIMESTAMP,
          next_follow_up_date = ${follow_up_date}
      WHERE id = ${id}
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error creating customer interaction:', error);
    return Response.json({ error: 'Failed to create customer interaction' }, { status: 500 });
  }
}