import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const { imageBase64, customerId } = body;

    if (!imageBase64) {
      return Response.json({ error: "Image is required" }, { status: 400 });
    }

    // Call ChatGPT-4 API for pest identification
    const chatGptResponse = await fetch(
      "/integrations/chat-gpt/conversationgpt4",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content:
                "You are a lawn care expert specializing in pest, disease, and weed identification. When given an image description, provide detailed analysis in JSON format.",
            },
            {
              role: "user",
              content: `Analyze this lawn/garden image (provided as base64): ${imageBase64.substring(0, 100)}...

Please identify any pests, diseases, or weeds and provide:

1. IDENTIFICATION: What specific pest, disease, or weed is shown?
2. CONFIDENCE: Your confidence level (0-100%)
3. SEVERITY: Rate the severity as Low, Medium, or High
4. TREATMENT: Specific treatment recommendations including products and application methods
5. TIMING: Best time of year/season for treatment
6. COST_RANGE: Estimated treatment cost range
7. PREVENTION: Prevention tips to avoid future occurrences`,
            },
          ],
          json_schema: {
            name: "pest_analysis",
            schema: {
              type: "object",
              properties: {
                identification: { type: "string" },
                confidence: { type: "number" },
                severity: { type: "string" },
                treatment: { type: "string" },
                timing: { type: "string" },
                costRange: { type: "string" },
                prevention: { type: "string" },
              },
              required: [
                "identification",
                "confidence",
                "severity",
                "treatment",
                "timing",
                "costRange",
                "prevention",
              ],
              additionalProperties: false,
            },
          },
        }),
      },
    );

    if (!chatGptResponse.ok) {
      throw new Error("Failed to analyze with ChatGPT-4");
    }

    const analysisData = await chatGptResponse.json();
    const analysisResult = JSON.parse(analysisData.choices[0].message.content);

    // Save the identification result to the database
    const savedResult = await sql`
      INSERT INTO pest_identifications (
        customer_id, image_url, identified_pest, confidence_score,
        treatment_recommendation, estimated_treatment_cost, severity_level, seasonal_timing
      ) VALUES (
        ${customerId}, ${imageBase64}, ${analysisResult.identification}, ${analysisResult.confidence},
        ${analysisResult.treatment}, ${analysisResult.costRange}, ${analysisResult.severity}, ${analysisResult.timing}
      ) RETURNING *
    `;

    // Return the analysis result with additional formatting
    const response = {
      id: savedResult[0].id,
      ...analysisResult,
      imageUrl: imageBase64,
      customerId: customerId,
      createdAt: savedResult[0].created_at,
    };

    return Response.json(response);
  } catch (error) {
    console.error("Error in pest identification:", error);
    return Response.json(
      {
        error: "Failed to identify pest/weed. Please try again.",
      },
      { status: 500 },
    );
  }
}

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const customerId = searchParams.get("customerId");

    let query = "SELECT * FROM pest_identifications";
    let params = [];

    if (customerId) {
      query += " WHERE customer_id = $1";
      params = [customerId];
    }

    query += " ORDER BY created_at DESC";

    const identifications = await sql(query, params);
    return Response.json(identifications);
  } catch (error) {
    console.error("Error fetching pest identifications:", error);
    return Response.json(
      { error: "Failed to fetch identifications" },
      { status: 500 },
    );
  }
}
