import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get('search');
    
    let query = 'SELECT * FROM customers';
    let params = [];
    
    if (search) {
      query += ' WHERE LOWER(name) LIKE LOWER($1) OR LOWER(email) LIKE LOWER($1) OR LOWER(phone) LIKE LOWER($1)';
      params = [`%${search}%`];
    }
    
    query += ' ORDER BY created_at DESC';
    
    const customers = await sql(query, params);
    return Response.json(customers);
  } catch (error) {
    console.error('Error fetching customers:', error);
    return Response.json({ error: 'Failed to fetch customers' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name,
      email,
      phone,
      address,
      city,
      state,
      zip_code,
      property_size_sqft,
      grass_type,
      terrain_difficulty,
      accessibility_notes
    } = body;

    if (!name) {
      return Response.json({ error: 'Customer name is required' }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO customers (
        name, email, phone, address, city, state, zip_code,
        property_size_sqft, grass_type, terrain_difficulty, accessibility_notes
      ) VALUES (
        ${name}, ${email}, ${phone}, ${address}, ${city}, ${state}, ${zip_code},
        ${property_size_sqft}, ${grass_type}, ${terrain_difficulty}, ${accessibility_notes}
      ) RETURNING *
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error creating customer:', error);
    return Response.json({ error: 'Failed to create customer' }, { status: 500 });
  }
}