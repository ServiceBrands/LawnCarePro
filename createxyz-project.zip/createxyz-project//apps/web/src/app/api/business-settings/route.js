import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const settings = await sql`
      SELECT * FROM business_settings ORDER BY created_at DESC LIMIT 1
    `;
    return Response.json(settings);
  } catch (error) {
    console.error('Error fetching business settings:', error);
    return Response.json({ error: 'Failed to fetch business settings' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      business_name,
      owner_name,
      phone,
      email,
      address,
      license_number,
      insurance_cost_monthly,
      fuel_cost_per_gallon,
      default_profit_margin,
      hourly_labor_rate
    } = body;

    // Check if settings already exist
    const existingSettings = await sql`
      SELECT id FROM business_settings ORDER BY created_at DESC LIMIT 1
    `;

    let result;
    if (existingSettings.length > 0) {
      // Update existing settings
      result = await sql`
        UPDATE business_settings 
        SET 
          business_name = ${business_name},
          owner_name = ${owner_name},
          phone = ${phone},
          email = ${email},
          address = ${address},
          license_number = ${license_number},
          insurance_cost_monthly = ${insurance_cost_monthly},
          fuel_cost_per_gallon = ${fuel_cost_per_gallon},
          default_profit_margin = ${default_profit_margin},
          hourly_labor_rate = ${hourly_labor_rate},
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ${existingSettings[0].id}
        RETURNING *
      `;
    } else {
      // Create new settings
      result = await sql`
        INSERT INTO business_settings (
          business_name, owner_name, phone, email, address, license_number,
          insurance_cost_monthly, fuel_cost_per_gallon, default_profit_margin, hourly_labor_rate
        ) VALUES (
          ${business_name}, ${owner_name}, ${phone}, ${email}, ${address}, ${license_number},
          ${insurance_cost_monthly}, ${fuel_cost_per_gallon}, ${default_profit_margin}, ${hourly_labor_rate}
        ) RETURNING *
      `;
    }

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error saving business settings:', error);
    return Response.json({ error: 'Failed to save business settings' }, { status: 500 });
  }
}