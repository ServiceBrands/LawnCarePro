import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      serviceTypeId,
      propertySizeSqft,
      terrainDifficulty = 'flat',
      zipCode,
      customLaborRate,
      customProfitMargin,
      additionalMaterials = 0
    } = body;

    if (!serviceTypeId || !propertySizeSqft) {
      return Response.json({ 
        error: 'Service type and property size are required' 
      }, { status: 400 });
    }

    // Get service type details
    const serviceType = await sql`
      SELECT * FROM service_types WHERE id = ${serviceTypeId}
    `;

    if (serviceType.length === 0) {
      return Response.json({ error: 'Service type not found' }, { status: 404 });
    }

    const service = serviceType[0];

    // Get business settings for defaults
    const businessSettings = await sql`
      SELECT * FROM business_settings ORDER BY created_at DESC LIMIT 1
    `;

    const settings = businessSettings.length > 0 ? businessSettings[0] : {};

    // Get regional pricing if zip code provided
    let regionalMultiplier = 1.0;
    if (zipCode) {
      const regionalPricing = await sql`
        SELECT cost_of_living_multiplier FROM regional_pricing 
        WHERE zip_code = ${zipCode}
      `;
      if (regionalPricing.length > 0) {
        regionalMultiplier = parseFloat(regionalPricing[0].cost_of_living_multiplier) || 1.0;
      }
    }

    // Calculate terrain difficulty multiplier
    const terrainMultipliers = {
      'flat': 1.0,
      'slight_slope': 1.1,
      'steep_slope': 1.25,
      'obstacles': 1.15,
      'difficult_access': 1.3
    };
    const terrainMultiplier = terrainMultipliers[terrainDifficulty] || 1.0;

    // Calculate base price using per-1000-sqft model
    let basePrice;
    const minimumPrice = parseFloat(service.minimum_price) || 0;
    const minimumCoverage = parseInt(service.minimum_coverage_sqft) || 3000;
    const pricePerThousand = parseFloat(service.price_per_1000sqft) || 0;

    if (propertySizeSqft <= minimumCoverage) {
      // Property is within minimum coverage, charge minimum price
      basePrice = minimumPrice;
    } else {
      // Property exceeds minimum coverage, calculate additional cost
      const additionalSqft = propertySizeSqft - minimumCoverage;
      const additionalThousands = additionalSqft / 1000;
      const additionalCost = additionalThousands * pricePerThousand;
      basePrice = minimumPrice + additionalCost;
    }

    // Apply multipliers
    const adjustedPrice = basePrice * regionalMultiplier * terrainMultiplier;

    // Add additional materials cost
    const totalMaterialCost = adjustedPrice + additionalMaterials;

    // Calculate profit margin
    const profitMargin = customProfitMargin || parseFloat(settings.default_profit_margin) || 25.0;
    const profitMultiplier = 1 + (profitMargin / 100);
    const finalPrice = totalMaterialCost * profitMultiplier;

    // Calculate profit amount
    const profitAmount = finalPrice - totalMaterialCost;

    // Generate competitive range (±15% of final price)
    const competitiveRange = {
      low: Math.round((finalPrice * 0.85) * 100) / 100,
      high: Math.round((finalPrice * 1.15) * 100) / 100
    };

    // Prepare response
    const result = {
      serviceName: service.name,
      propertySize: propertySizeSqft,
      breakdown: {
        basePrice: Math.round(basePrice * 100) / 100,
        minimumPrice: minimumPrice,
        minimumCoverage: minimumCoverage,
        pricePerThousand: pricePerThousand,
        regionalMultiplier: regionalMultiplier,
        terrainMultiplier: terrainMultiplier,
        adjustedPrice: Math.round(adjustedPrice * 100) / 100,
        additionalMaterials: additionalMaterials,
        totalMaterialCost: Math.round(totalMaterialCost * 100) / 100,
        profitMargin: profitMargin,
        profitAmount: Math.round(profitAmount * 100) / 100,
        finalPrice: Math.round(finalPrice * 100) / 100,
        pricePerSqft: Math.round((finalPrice / propertySizeSqft) * 10000) / 10000
      },
      recommendations: {
        suggestedQuote: Math.round(finalPrice * 100) / 100,
        competitiveRange: competitiveRange
      },
      calculation: {
        formula: propertySizeSqft <= minimumCoverage 
          ? `Minimum price: $${minimumPrice} (covers up to ${minimumCoverage.toLocaleString()} sq ft)`
          : `Minimum: $${minimumPrice} + Additional: ${Math.round((propertySizeSqft - minimumCoverage) / 1000 * 100) / 100} × $${pricePerThousand}/1000sqft = $${Math.round(basePrice * 100) / 100}`,
        appliedMultipliers: {
          regional: regionalMultiplier,
          terrain: terrainMultiplier,
          profit: `${profitMargin}%`
        }
      }
    };

    return Response.json(result);

  } catch (error) {
    console.error('Error calculating pricing:', error);
    return Response.json({ error: 'Failed to calculate pricing' }, { status: 500 });
  }
}