import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const serviceTypes = await sql`
      SELECT * FROM service_types ORDER BY name
    `;
    return Response.json(serviceTypes);
  } catch (error) {
    console.error('Error fetching service types:', error);
    return Response.json({ error: 'Failed to fetch service types' }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      name,
      minimum_price,
      minimum_coverage_sqft,
      price_per_1000sqft,
      description
    } = body;

    if (!name || minimum_price === undefined || price_per_1000sqft === undefined) {
      return Response.json({ 
        error: 'Name, minimum price, and price per 1000 sqft are required' 
      }, { status: 400 });
    }

    const result = await sql`
      INSERT INTO service_types (
        name, minimum_price, minimum_coverage_sqft, price_per_1000sqft, description
      ) VALUES (
        ${name}, ${minimum_price}, ${minimum_coverage_sqft || 3000}, ${price_per_1000sqft}, ${description}
      ) RETURNING *
    `;

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error creating service type:', error);
    return Response.json({ error: 'Failed to create service type' }, { status: 500 });
  }
}

export async function PUT(request) {
  try {
    const body = await request.json();
    const {
      id,
      name,
      minimum_price,
      minimum_coverage_sqft,
      price_per_1000sqft,
      description
    } = body;

    if (!id) {
      return Response.json({ error: 'Service type ID is required' }, { status: 400 });
    }

    const result = await sql`
      UPDATE service_types 
      SET 
        name = ${name},
        minimum_price = ${minimum_price},
        minimum_coverage_sqft = ${minimum_coverage_sqft},
        price_per_1000sqft = ${price_per_1000sqft},
        description = ${description}
      WHERE id = ${id}
      RETURNING *
    `;

    if (result.length === 0) {
      return Response.json({ error: 'Service type not found' }, { status: 404 });
    }

    return Response.json(result[0]);
  } catch (error) {
    console.error('Error updating service type:', error);
    return Response.json({ error: 'Failed to update service type' }, { status: 500 });
  }
}