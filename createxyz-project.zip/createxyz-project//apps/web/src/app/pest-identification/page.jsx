import { useState } from 'react';
import { Camera, Upload, AlertCircle } from 'lucide-react';
import useUpload from '@/utils/useUpload';

export default function PestIdentificationPage() {
  const [imageUrl, setImageUrl] = useState('');
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [upload, { loading: uploadLoading }] = useUpload();
  const [analyzing, setAnalyzing] = useState(false);

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const { url, error } = await upload({ file });
      if (error) throw new Error(error);
      setImageUrl(url);
      await analyzePest(url);
    } catch (err) {
      console.error('Upload error:', err);
      setError('Failed to upload image. Please try again.');
    }
  };

  const analyzePest = async (url) => {
    setAnalyzing(true);
    setError(null);
    try {
      const response = await fetch('/api/pest-identification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image_url: url }),
      });

      if (!response.ok) {
        throw new Error('Failed to analyze image');
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error('Analysis error:', err);
      setError('Failed to analyze image. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Pest Identification</h1>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="text-center mb-8">
            <h2 className="text-xl font-semibold mb-2">Upload an Image</h2>
            <p className="text-gray-600">
              Take or upload a photo of the pest or affected area for AI analysis
            </p>
          </div>

          <div className="flex flex-col items-center gap-6">
            <div className="w-full max-w-md">
              <label
                htmlFor="image-upload"
                className="block w-full aspect-video border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-green-500 transition-colors"
              >
                <div className="flex flex-col items-center justify-center h-full p-6">
                  {imageUrl ? (
                    <img
                      src={imageUrl}
                      alt="Uploaded pest"
                      className="max-h-full object-contain"
                    />
                  ) : (
                    <>
                      <Upload className="h-12 w-12 text-gray-400 mb-4" />
                      <p className="text-sm text-gray-600">
                        Click or drag and drop to upload an image
                      </p>
                    </>
                  )}
                </div>
                <input
                  id="image-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageUpload}
                />
              </label>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-red-600">
                <AlertCircle size={20} />
                <p>{error}</p>
              </div>
            )}

            {(uploadLoading || analyzing) && (
              <div className="flex items-center gap-2 text-gray-600">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-gray-900"></div>
                <p>{uploadLoading ? 'Uploading...' : 'Analyzing...'}</p>
              </div>
            )}
          </div>
        </div>

        {result && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-medium text-gray-900 mb-2">Identified Pest</h3>
                <p className="text-gray-600 mb-4">{result.identified_pest}</p>

                <h3 className="font-medium text-gray-900 mb-2">Severity Level</h3>
                <div className="mb-4">
                  <span
                    className={`px-3 py-1 rounded-full text-sm font-medium ${
                      result.severity_level === 'high'
                        ? 'bg-red-100 text-red-800'
                        : result.severity_level === 'medium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {result.severity_level}
                  </span>
                </div>

                <h3 className="font-medium text-gray-900 mb-2">Confidence Score</h3>
                <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                  <div
                    className="bg-green-600 h-2.5 rounded-full"
                    style={{ width: `${result.confidence_score * 100}%` }}
                  ></div>
                </div>
              </div>

              <div>
                <h3 className="font-medium text-gray-900 mb-2">
                  Treatment Recommendation
                </h3>
                <p className="text-gray-600 mb-4">{result.treatment_recommendation}</p>

                <h3 className="font-medium text-gray-900 mb-2">Seasonal Timing</h3>
                <p className="text-gray-600 mb-4">{result.seasonal_timing}</p>

                <h3 className="font-medium text-gray-900 mb-2">
                  Estimated Treatment Cost
                </h3>
                <p className="text-2xl font-bold text-gray-900">
                  ${result.estimated_treatment_cost.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}