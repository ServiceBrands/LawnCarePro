import React, { useState, useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  ScrollView,
  Image,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Camera, CameraView } from "expo-camera";
import * as ImagePicker from "expo-image-picker";
import {
  Camera as CameraIcon,
  Image as ImageIcon,
  Bug,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react-native";
import useUpload from "@/utils/useUpload";
import { router } from "expo-router";

export default function PestIdentificationScreen() {
  const insets = useSafeAreaInsets();
  const cameraRef = useRef(null);
  const [upload, { loading: uploading }] = useUpload();

  const [hasPermission, setHasPermission] = useState(null);
  const [showCamera, setShowCamera] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [capturedImage, setCapturedImage] = useState(null);

  React.useEffect(() => {
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === "granted");
    })();
  }, []);

  const takePicture = async () => {
    if (cameraRef.current) {
      try {
        const photo = await cameraRef.current.takePictureAsync({
          quality: 0.8,
          base64: true,
        });
        setCapturedImage(photo);
        setShowCamera(false);
        await analyzeImage(photo.base64);
      } catch (error) {
        console.error("Error taking picture:", error);
        Alert.alert("Error", "Failed to take picture");
      }
    }
  };

  const pickImage = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
        base64: true,
      });

      if (!result.canceled && result.assets[0]) {
        const image = result.assets[0];
        setCapturedImage(image);
        await analyzeImage(image.base64);
      }
    } catch (error) {
      console.error("Error picking image:", error);
      Alert.alert("Error", "Failed to pick image");
    }
  };

  const analyzeImage = async (base64Image) => {
    try {
      setAnalyzing(true);
      setAnalysisResult(null);

      // First, analyze the image with GPT Vision
      const visionResponse = await fetch("/integrations/gpt-vision/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messages: [
            {
              role: "system",
              content: [
                {
                  type: "text",
                  text: 'You are a lawn care and pest control expert. Analyze the image and identify any pests, diseases, or weeds. Provide detailed information about the problem, its severity, and treatment recommendations. Format your response as JSON with the following structure: { identification: string, confidence: number (0-100), severity: "low"|"medium"|"high", costRange: string, treatment: string, timing: string, prevention: string }',
                },
              ],
            },
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: "What lawn problem can you identify in this image? Please provide a detailed analysis.",
                },
                {
                  type: "image_url",
                  image_url: {
                    url: `data:image/jpeg;base64,${base64Image}`,
                  },
                },
              ],
            },
          ],
        }),
      });

      if (!visionResponse.ok) {
        throw new Error("Failed to analyze image with AI");
      }

      const visionData = await visionResponse.json();
      const analysis = JSON.parse(visionData.choices[0].message.content);

      // Now save the analysis to the database
      const response = await fetch("/api/pest-identification", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          image_url: `data:image/jpeg;base64,${base64Image}`,
          identified_pest: analysis.identification,
          confidence_score: analysis.confidence / 100,
          treatment_recommendation: analysis.treatment,
          estimated_treatment_cost: parseFloat(
            analysis.costRange.match(/\$(\d+)/)[1],
          ),
          severity_level: analysis.severity,
          seasonal_timing: analysis.timing,
          customerId: null, // Can be linked to customer later
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to save analysis");
      }

      setAnalysisResult(analysis);
    } catch (error) {
      console.error("Error analyzing image:", error);
      Alert.alert("Error", "Failed to analyze image. Please try again.");
    } finally {
      setAnalyzing(false);
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity?.toLowerCase()) {
      case "low":
        return "#16A34A";
      case "medium":
        return "#F59E0B";
      case "high":
        return "#DC2626";
      default:
        return "#6B7280";
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity?.toLowerCase()) {
      case "low":
        return CheckCircle;
      case "medium":
        return AlertTriangle;
      case "high":
        return AlertTriangle;
      default:
        return Bug;
    }
  };

  const resetAnalysis = () => {
    setCapturedImage(null);
    setAnalysisResult(null);
    setShowCamera(false);
  };

  if (hasPermission === null) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <ActivityIndicator size="large" color="#16A34A" />
        <Text style={{ marginTop: 10, color: "#6B7280" }}>
          Requesting camera permission...
        </Text>
      </View>
    );
  }

  if (hasPermission === false) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
          padding: 20,
        }}
      >
        <CameraIcon color="#6B7280" size={48} />
        <Text
          style={{
            fontSize: 18,
            fontWeight: "600",
            marginTop: 20,
            textAlign: "center",
            color: "#111827",
          }}
        >
          Camera Permission Required
        </Text>
        <Text style={{ color: "#6B7280", textAlign: "center", marginTop: 10 }}>
          Please enable camera access in your device settings to use pest
          identification.
        </Text>
      </View>
    );
  }

  if (showCamera) {
    return (
      <View style={{ flex: 1, paddingTop: insets.top }}>
        <CameraView ref={cameraRef} style={{ flex: 1 }} facing="back">
          <View
            style={{
              position: "absolute",
              bottom: insets.bottom + 30,
              left: 0,
              right: 0,
              alignItems: "center",
            }}
          >
            <View style={{ flexDirection: "row", gap: 20 }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "rgba(0,0,0,0.6)",
                  paddingVertical: 15,
                  paddingHorizontal: 20,
                  borderRadius: 8,
                }}
                onPress={() => setShowCamera(false)}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>Cancel</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  backgroundColor: "#16A34A",
                  width: 70,
                  height: 70,
                  borderRadius: 35,
                  justifyContent: "center",
                  alignItems: "center",
                }}
                onPress={takePicture}
              >
                <CameraIcon color="#fff" size={30} />
              </TouchableOpacity>
            </View>
          </View>
        </CameraView>
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#16A34A",
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Bug color="#fff" size={24} />
          <Text
            style={{
              color: "#fff",
              fontSize: 24,
              fontWeight: "bold",
              marginLeft: 10,
            }}
          >
            Pest & Weed ID
          </Text>
        </View>
        <Text style={{ color: "#E5F3E5", marginTop: 5 }}>
          Take a photo to identify pests, diseases, and weeds
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {!capturedImage && !analyzing && !analysisResult && (
          <View
            style={{
              backgroundColor: "#fff",
              margin: 20,
              borderRadius: 12,
              padding: 30,
              alignItems: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Bug color="#16A34A" size={64} />
            <Text
              style={{
                fontSize: 20,
                fontWeight: "600",
                marginTop: 20,
                marginBottom: 10,
                color: "#111827",
                textAlign: "center",
              }}
            >
              Identify Lawn Problems
            </Text>
            <Text
              style={{
                color: "#6B7280",
                textAlign: "center",
                marginBottom: 30,
                lineHeight: 20,
              }}
            >
              Take a clear photo of the affected area. Our AI will identify
              pests, diseases, and weeds, then provide treatment
              recommendations.
            </Text>

            <View style={{ width: "100%", gap: 15 }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "#16A34A",
                  paddingVertical: 15,
                  borderRadius: 8,
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
                onPress={() => setShowCamera(true)}
              >
                <CameraIcon color="#fff" size={20} />
                <Text
                  style={{ color: "#fff", fontWeight: "600", marginLeft: 8 }}
                >
                  Take Photo
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  backgroundColor: "#6B7280",
                  paddingVertical: 15,
                  borderRadius: 8,
                  alignItems: "center",
                  flexDirection: "row",
                  justifyContent: "center",
                }}
                onPress={pickImage}
              >
                <ImageIcon color="#fff" size={20} />
                <Text
                  style={{ color: "#fff", fontWeight: "600", marginLeft: 8 }}
                >
                  Choose from Gallery
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Captured Image */}
        {capturedImage && (
          <View
            style={{
              backgroundColor: "#fff",
              margin: 20,
              borderRadius: 12,
              padding: 20,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginBottom: 15,
                color: "#111827",
              }}
            >
              Captured Image
            </Text>
            <Image
              source={{ uri: capturedImage.uri }}
              style={{
                width: "100%",
                height: 200,
                borderRadius: 8,
                marginBottom: 15,
              }}
              resizeMode="cover"
            />

            {!analyzing && !analysisResult && (
              <TouchableOpacity
                style={{
                  backgroundColor: "#6B7280",
                  paddingVertical: 10,
                  borderRadius: 6,
                  alignItems: "center",
                }}
                onPress={resetAnalysis}
              >
                <Text style={{ color: "#fff", fontWeight: "500" }}>
                  Take Another Photo
                </Text>
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Analysis Loading */}
        {analyzing && (
          <View
            style={{
              backgroundColor: "#fff",
              margin: 20,
              borderRadius: 12,
              padding: 30,
              alignItems: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <ActivityIndicator size="large" color="#16A34A" />
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginTop: 15,
                color: "#111827",
              }}
            >
              Analyzing Image...
            </Text>
            <Text
              style={{ color: "#6B7280", textAlign: "center", marginTop: 5 }}
            >
              Our AI is identifying pests, diseases, and weeds in your photo
            </Text>
          </View>
        )}

        {/* Analysis Results */}
        {analysisResult && (
          <View
            style={{
              backgroundColor: "#fff",
              margin: 20,
              borderRadius: 12,
              padding: 20,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginBottom: 20,
                color: "#111827",
              }}
            >
              Analysis Results
            </Text>

            {/* Identification */}
            <View
              style={{
                backgroundColor: "#F3F4F6",
                padding: 15,
                borderRadius: 8,
                marginBottom: 15,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 10,
                }}
              >
                <Bug color="#16A34A" size={20} />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    marginLeft: 8,
                    color: "#111827",
                  }}
                >
                  Identified Issue
                </Text>
              </View>
              <Text
                style={{ fontSize: 18, fontWeight: "bold", color: "#111827" }}
              >
                {analysisResult.identification}
              </Text>
              <Text style={{ color: "#6B7280", marginTop: 5 }}>
                Confidence: {analysisResult.confidence}%
              </Text>
            </View>

            {/* Severity */}
            <View
              style={{
                backgroundColor: getSeverityColor(analysisResult.severity),
                padding: 15,
                borderRadius: 8,
                marginBottom: 15,
              }}
            >
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 5,
                }}
              >
                {React.createElement(getSeverityIcon(analysisResult.severity), {
                  color: "#fff",
                  size: 20,
                })}
                <Text
                  style={{
                    color: "#fff",
                    fontSize: 16,
                    fontWeight: "600",
                    marginLeft: 8,
                  }}
                >
                  Severity: {analysisResult.severity}
                </Text>
              </View>
              <Text style={{ color: "#fff", opacity: 0.9 }}>
                Cost Range: {analysisResult.costRange}
              </Text>
            </View>

            {/* Treatment */}
            <View style={{ marginBottom: 15 }}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 10,
                }}
              >
                <CheckCircle color="#16A34A" size={20} />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    marginLeft: 8,
                    color: "#111827",
                  }}
                >
                  Treatment Recommendations
                </Text>
              </View>
              <Text style={{ color: "#374151", lineHeight: 20 }}>
                {analysisResult.treatment}
              </Text>
            </View>

            {/* Timing */}
            <View style={{ marginBottom: 15 }}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginBottom: 10,
                }}
              >
                <Clock color="#F59E0B" size={20} />
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    marginLeft: 8,
                    color: "#111827",
                  }}
                >
                  Best Treatment Timing
                </Text>
              </View>
              <Text style={{ color: "#374151" }}>{analysisResult.timing}</Text>
            </View>

            {/* Prevention */}
            {analysisResult.prevention && (
              <View
                style={{
                  backgroundColor: "#EFF6FF",
                  padding: 15,
                  borderRadius: 8,
                  marginBottom: 15,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    marginBottom: 8,
                    color: "#1E40AF",
                  }}
                >
                  Prevention Tips
                </Text>
                <Text style={{ color: "#1E40AF", lineHeight: 18 }}>
                  {analysisResult.prevention}
                </Text>
              </View>
            )}

            {/* Action Buttons */}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <TouchableOpacity
                style={{
                  flex: 1,
                  backgroundColor: "#16A34A",
                  paddingVertical: 12,
                  borderRadius: 6,
                  alignItems: "center",
                }}
                onPress={() => {
                  // Navigate to pricing calculator with the pest treatment service
                  router.push({
                    pathname: "/pricing",
                    params: {
                      serviceType: "pest_treatment",
                      pestName: analysisResult.identification,
                      estimatedCost: analysisResult.costRange,
                    },
                  });
                }}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>
                  Calculate Treatment Cost
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={{
                  backgroundColor: "#6B7280",
                  paddingVertical: 12,
                  paddingHorizontal: 15,
                  borderRadius: 6,
                  alignItems: "center",
                }}
                onPress={resetAnalysis}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>
                  New Analysis
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
