import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Users,
  Search,
  Plus,
  Phone,
  Mail,
  MapPin,
  Edit,
  Trash2,
  MessageSquare,
  Calendar,
  Clock,
  Tag,
} from "lucide-react-native";
import { format } from "date-fns";

export default function CustomersScreen() {
  const insets = useSafeAreaInsets();
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showInteractionModal, setShowInteractionModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip_code: "",
    property_size_sqft: "",
    grass_type: "",
    terrain_difficulty: "flat",
    accessibility_notes: "",
  });

  // Interaction form state
  const [interactionData, setInteractionData] = useState({
    interaction_type: "",
    notes: "",
    follow_up_needed: false,
    follow_up_date: null,
  });

  useEffect(() => {
    fetchCustomers();
  }, []);

  const fetchCustomers = async (search = "") => {
    try {
      setLoading(true);
      const url = search
        ? `/api/customers?search=${encodeURIComponent(search)}`
        : "/api/customers";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Failed to fetch customers");
      const data = await response.json();
      setCustomers(data);
    } catch (error) {
      console.error("Error fetching customers:", error);
      Alert.alert("Error", "Failed to load customers");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (query) => {
    setSearchQuery(query);
    if (query.length > 2 || query.length === 0) {
      fetchCustomers(query);
    }
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone: "",
      address: "",
      city: "",
      state: "",
      zip_code: "",
      property_size_sqft: "",
      grass_type: "",
      terrain_difficulty: "flat",
      accessibility_notes: "",
    });
    setEditingCustomer(null);
  };

  const openAddModal = () => {
    resetForm();
    setShowAddModal(true);
  };

  const openEditModal = (customer) => {
    setFormData({
      name: customer.name || "",
      email: customer.email || "",
      phone: customer.phone || "",
      address: customer.address || "",
      city: customer.city || "",
      state: customer.state || "",
      zip_code: customer.zip_code || "",
      property_size_sqft: customer.property_size_sqft?.toString() || "",
      grass_type: customer.grass_type || "",
      terrain_difficulty: customer.terrain_difficulty || "flat",
      accessibility_notes: customer.accessibility_notes || "",
    });
    setEditingCustomer(customer);
    setShowAddModal(true);
  };

  const closeModal = () => {
    setShowAddModal(false);
    resetForm();
  };

  const saveCustomer = async () => {
    if (!formData.name.trim()) {
      Alert.alert("Error", "Customer name is required");
      return;
    }

    try {
      const url = editingCustomer
        ? `/api/customers/${editingCustomer.id}`
        : "/api/customers";
      const method = editingCustomer ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          property_size_sqft: formData.property_size_sqft
            ? parseInt(formData.property_size_sqft)
            : null,
        }),
      });

      if (!response.ok) throw new Error("Failed to save customer");

      closeModal();
      fetchCustomers(searchQuery);
      Alert.alert(
        "Success",
        `Customer ${editingCustomer ? "updated" : "created"} successfully`,
      );
    } catch (error) {
      console.error("Error saving customer:", error);
      Alert.alert("Error", "Failed to save customer");
    }
  };

  const deleteCustomer = (customer) => {
    Alert.alert(
      "Delete Customer",
      `Are you sure you want to delete ${customer.name}?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const response = await fetch(`/api/customers/${customer.id}`, {
                method: "DELETE",
              });
              if (!response.ok) throw new Error("Failed to delete customer");
              fetchCustomers(searchQuery);
              Alert.alert("Success", "Customer deleted successfully");
            } catch (error) {
              console.error("Error deleting customer:", error);
              Alert.alert("Error", "Failed to delete customer");
            }
          },
        },
      ],
    );
  };

  const formatPhoneNumber = (phone) => {
    if (!phone) return "";
    const cleaned = phone.replace(/\D/g, "");
    if (cleaned.length === 10) {
      return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    }
    return phone;
  };

  const addInteraction = async () => {
    if (!interactionData.interaction_type || !interactionData.notes) {
      Alert.alert("Error", "Interaction type and notes are required");
      return;
    }

    try {
      const response = await fetch(
        `/api/customers/${selectedCustomer.id}/interactions`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(interactionData),
        },
      );

      if (!response.ok) throw new Error("Failed to add interaction");

      setShowInteractionModal(false);
      setInteractionData({
        interaction_type: "",
        notes: "",
        follow_up_needed: false,
        follow_up_date: null,
      });
      fetchCustomers(searchQuery);
      Alert.alert("Success", "Interaction added successfully");
    } catch (error) {
      console.error("Error adding interaction:", error);
      Alert.alert("Error", "Failed to add interaction");
    }
  };

  const renderCustomerCard = (customer) => (
    <View
      key={customer.id}
      style={{
        backgroundColor: "#fff",
        marginHorizontal: 20,
        marginBottom: 15,
        borderRadius: 12,
        padding: 20,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 8,
            }}
          >
            {customer.name}
          </Text>

          {/* Status Badge */}
          <View
            style={{
              backgroundColor:
                customer.status === "lead" ? "#FEF3C7" : "#D1FAE5",
              paddingHorizontal: 8,
              paddingVertical: 4,
              borderRadius: 12,
              alignSelf: "flex-start",
              marginBottom: 8,
            }}
          >
            <Text
              style={{
                color: customer.status === "lead" ? "#92400E" : "#065F46",
                fontSize: 12,
                fontWeight: "500",
              }}
            >
              {customer.status || "lead"}
            </Text>
          </View>

          {customer.email && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <Mail color="#6B7280" size={16} />
              <Text style={{ color: "#6B7280", marginLeft: 8 }}>
                {customer.email}
              </Text>
            </View>
          )}

          {customer.phone && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <Phone color="#6B7280" size={16} />
              <Text style={{ color: "#6B7280", marginLeft: 8 }}>
                {formatPhoneNumber(customer.phone)}
              </Text>
            </View>
          )}

          {customer.address && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <MapPin color="#6B7280" size={16} />
              <Text style={{ color: "#6B7280", marginLeft: 8, flex: 1 }}>
                {customer.address}
                {customer.city && `, ${customer.city}`}
                {customer.state && `, ${customer.state}`}
                {customer.zip_code && ` ${customer.zip_code}`}
              </Text>
            </View>
          )}

          {/* Last Contact & Next Follow-up */}
          {(customer.last_contact_date || customer.next_follow_up_date) && (
            <View
              style={{
                marginTop: 8,
                borderTopWidth: 1,
                borderTopColor: "#E5E7EB",
                paddingTop: 8,
              }}
            >
              {customer.last_contact_date && (
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    marginBottom: 4,
                  }}
                >
                  <Clock color="#6B7280" size={14} />
                  <Text
                    style={{ color: "#6B7280", marginLeft: 6, fontSize: 12 }}
                  >
                    Last Contact:{" "}
                    {format(
                      new Date(customer.last_contact_date),
                      "MMM d, yyyy",
                    )}
                  </Text>
                </View>
              )}
              {customer.next_follow_up_date && (
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <Calendar color="#6B7280" size={14} />
                  <Text
                    style={{ color: "#6B7280", marginLeft: 6, fontSize: 12 }}
                  >
                    Follow-up:{" "}
                    {format(
                      new Date(customer.next_follow_up_date),
                      "MMM d, yyyy",
                    )}
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* Tags */}
          {customer.tags && customer.tags.length > 0 && (
            <View
              style={{
                flexDirection: "row",
                flexWrap: "wrap",
                gap: 4,
                marginTop: 8,
              }}
            >
              {customer.tags.map((tag, index) => (
                <View
                  key={index}
                  style={{
                    backgroundColor: "#F3F4F6",
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 12,
                    flexDirection: "row",
                    alignItems: "center",
                  }}
                >
                  <Tag color="#6B7280" size={12} />
                  <Text
                    style={{ color: "#374151", fontSize: 12, marginLeft: 4 }}
                  >
                    {tag}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={{ flexDirection: "row", gap: 8 }}>
          <TouchableOpacity
            style={{
              backgroundColor: "#EFF6FF",
              padding: 8,
              borderRadius: 6,
            }}
            onPress={() => {
              setSelectedCustomer(customer);
              setShowInteractionModal(true);
            }}
          >
            <MessageSquare color="#2563EB" size={16} />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: "#F3F4F6",
              padding: 8,
              borderRadius: 6,
            }}
            onPress={() => openEditModal(customer)}
          >
            <Edit color="#6B7280" size={16} />
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: "#FEE2E2",
              padding: 8,
              borderRadius: 6,
            }}
            onPress={() => deleteCustomer(customer)}
          >
            <Trash2 color="#DC2626" size={16} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#16A34A",
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Users color="#fff" size={24} />
            <Text
              style={{
                color: "#fff",
                fontSize: 24,
                fontWeight: "bold",
                marginLeft: 10,
              }}
            >
              Customers
            </Text>
          </View>
          <TouchableOpacity
            style={{
              backgroundColor: "rgba(255,255,255,0.2)",
              padding: 8,
              borderRadius: 8,
            }}
            onPress={openAddModal}
          >
            <Plus color="#fff" size={20} />
          </TouchableOpacity>
        </View>
        <Text style={{ color: "#E5F3E5", marginTop: 5 }}>
          Manage your customer database
        </Text>
      </View>

      {/* Search */}
      <View
        style={{
          backgroundColor: "#fff",
          margin: 20,
          borderRadius: 12,
          padding: 15,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.1,
          shadowRadius: 4,
          elevation: 3,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Search color="#6B7280" size={20} />
          <TextInput
            style={{
              flex: 1,
              marginLeft: 10,
              fontSize: 16,
              color: "#111827",
            }}
            placeholder="Search customers..."
            value={searchQuery}
            onChangeText={handleSearch}
          />
        </View>
      </View>

      {/* Customer List */}
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={{ alignItems: "center", marginTop: 50 }}>
            <ActivityIndicator size="large" color="#16A34A" />
            <Text style={{ marginTop: 10, color: "#6B7280" }}>
              Loading customers...
            </Text>
          </View>
        ) : customers.length === 0 ? (
          <View
            style={{
              backgroundColor: "#fff",
              margin: 20,
              borderRadius: 12,
              padding: 30,
              alignItems: "center",
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Users color="#6B7280" size={48} />
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginTop: 15,
                color: "#111827",
                textAlign: "center",
              }}
            >
              {searchQuery ? "No customers found" : "No customers yet"}
            </Text>
            <Text
              style={{
                color: "#6B7280",
                textAlign: "center",
                marginTop: 5,
                marginBottom: 20,
              }}
            >
              {searchQuery
                ? "Try a different search term"
                : "Add your first customer to get started"}
            </Text>
            {!searchQuery && (
              <TouchableOpacity
                style={{
                  backgroundColor: "#16A34A",
                  paddingVertical: 12,
                  paddingHorizontal: 20,
                  borderRadius: 8,
                }}
                onPress={openAddModal}
              >
                <Text style={{ color: "#fff", fontWeight: "600" }}>
                  Add Customer
                </Text>
              </TouchableOpacity>
            )}
          </View>
        ) : (
          customers.map(renderCustomerCard)
        )}
      </ScrollView>

      {/* Add/Edit Customer Modal */}
      <Modal
        visible={showAddModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#F9FAFB",
            paddingTop: insets.top,
          }}
        >
          {/* Modal Header */}
          <View
            style={{
              backgroundColor: "#16A34A",
              paddingHorizontal: 20,
              paddingVertical: 20,
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 20,
                  fontWeight: "bold",
                }}
              >
                {editingCustomer ? "Edit Customer" : "Add Customer"}
              </Text>
              <TouchableOpacity onPress={closeModal}>
                <Text style={{ color: "#fff", fontSize: 16 }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>

          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
            showsVerticalScrollIndicator={false}
          >
            {/* Basic Information */}
            <View
              style={{
                backgroundColor: "#fff",
                margin: 20,
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 15,
                  color: "#111827",
                }}
              >
                Basic Information
              </Text>

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Name *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="Customer name"
                value={formData.name}
                onChangeText={(text) =>
                  setFormData({ ...formData, name: text })
                }
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Email
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="email@example.com"
                value={formData.email}
                onChangeText={(text) =>
                  setFormData({ ...formData, email: text })
                }
                keyboardType="email-address"
                autoCapitalize="none"
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Phone
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="(555) 123-4567"
                value={formData.phone}
                onChangeText={(text) =>
                  setFormData({ ...formData, phone: text })
                }
                keyboardType="phone-pad"
              />
            </View>

            {/* Address Information */}
            <View
              style={{
                backgroundColor: "#fff",
                marginHorizontal: 20,
                marginBottom: 20,
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 15,
                  color: "#111827",
                }}
              >
                Address
              </Text>

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Street Address
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="123 Main St"
                value={formData.address}
                onChangeText={(text) =>
                  setFormData({ ...formData, address: text })
                }
              />

              <View style={{ flexDirection: "row", gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      marginBottom: 8,
                      color: "#374151",
                    }}
                  >
                    City
                  </Text>
                  <TextInput
                    style={{
                      borderWidth: 1,
                      borderColor: "#D1D5DB",
                      borderRadius: 8,
                      padding: 12,
                      fontSize: 16,
                      marginBottom: 15,
                      backgroundColor: "#fff",
                    }}
                    placeholder="City"
                    value={formData.city}
                    onChangeText={(text) =>
                      setFormData({ ...formData, city: text })
                    }
                  />
                </View>

                <View style={{ width: 80 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      marginBottom: 8,
                      color: "#374151",
                    }}
                  >
                    State
                  </Text>
                  <TextInput
                    style={{
                      borderWidth: 1,
                      borderColor: "#D1D5DB",
                      borderRadius: 8,
                      padding: 12,
                      fontSize: 16,
                      marginBottom: 15,
                      backgroundColor: "#fff",
                    }}
                    placeholder="ST"
                    value={formData.state}
                    onChangeText={(text) =>
                      setFormData({ ...formData, state: text })
                    }
                    maxLength={2}
                    autoCapitalize="characters"
                  />
                </View>

                <View style={{ width: 100 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      marginBottom: 8,
                      color: "#374151",
                    }}
                  >
                    Zip Code
                  </Text>
                  <TextInput
                    style={{
                      borderWidth: 1,
                      borderColor: "#D1D5DB",
                      borderRadius: 8,
                      padding: 12,
                      fontSize: 16,
                      marginBottom: 15,
                      backgroundColor: "#fff",
                    }}
                    placeholder="12345"
                    value={formData.zip_code}
                    onChangeText={(text) =>
                      setFormData({ ...formData, zip_code: text })
                    }
                    keyboardType="numeric"
                    maxLength={5}
                  />
                </View>
              </View>
            </View>

            {/* Property Information */}
            <View
              style={{
                backgroundColor: "#fff",
                marginHorizontal: 20,
                marginBottom: 20,
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 15,
                  color: "#111827",
                }}
              >
                Property Details
              </Text>

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Property Size (sq ft)
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="e.g. 5000"
                value={formData.property_size_sqft}
                onChangeText={(text) =>
                  setFormData({ ...formData, property_size_sqft: text })
                }
                keyboardType="numeric"
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Grass Type
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="e.g. Bermuda, Zoysia, Fescue"
                value={formData.grass_type}
                onChangeText={(text) =>
                  setFormData({ ...formData, grass_type: text })
                }
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Accessibility Notes
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  backgroundColor: "#fff",
                  height: 80,
                  textAlignVertical: "top",
                }}
                placeholder="Gates, stairs, obstacles, etc."
                value={formData.accessibility_notes}
                onChangeText={(text) =>
                  setFormData({ ...formData, accessibility_notes: text })
                }
                multiline
              />
            </View>

            {/* Save Button */}
            <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "#16A34A",
                  paddingVertical: 15,
                  borderRadius: 8,
                  alignItems: "center",
                }}
                onPress={saveCustomer}
              >
                <Text
                  style={{ color: "#fff", fontWeight: "600", fontSize: 16 }}
                >
                  {editingCustomer ? "Update Customer" : "Add Customer"}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>

      {/* Add Interaction Modal */}
      <Modal
        visible={showInteractionModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#F9FAFB",
            paddingTop: insets.top,
          }}
        >
          <View
            style={{
              backgroundColor: "#16A34A",
              paddingHorizontal: 20,
              paddingVertical: 20,
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 20,
                  fontWeight: "bold",
                }}
              >
                Add Interaction
              </Text>
              <TouchableOpacity onPress={() => setShowInteractionModal(false)}>
                <Text style={{ color: "#fff", fontSize: 16 }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>

          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{ padding: 20 }}
            showsVerticalScrollIndicator={false}
          >
            <View
              style={{
                backgroundColor: "#fff",
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Interaction Type *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="e.g. Phone Call, Site Visit, Email"
                value={interactionData.interaction_type}
                onChangeText={(text) =>
                  setInteractionData({
                    ...interactionData,
                    interaction_type: text,
                  })
                }
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Notes *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  backgroundColor: "#fff",
                  height: 100,
                  textAlignVertical: "top",
                }}
                placeholder="Details about the interaction..."
                value={interactionData.notes}
                onChangeText={(text) =>
                  setInteractionData({ ...interactionData, notes: text })
                }
                multiline
              />

              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  marginTop: 15,
                }}
              >
                <TouchableOpacity
                  onPress={() =>
                    setInteractionData({
                      ...interactionData,
                      follow_up_needed: !interactionData.follow_up_needed,
                    })
                  }
                  style={{
                    width: 24,
                    height: 24,
                    borderWidth: 2,
                    borderColor: interactionData.follow_up_needed
                      ? "#16A34A"
                      : "#D1D5DB",
                    borderRadius: 6,
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: interactionData.follow_up_needed
                      ? "#16A34A"
                      : "#fff",
                  }}
                >
                  {interactionData.follow_up_needed && (
                    <View
                      style={{
                        width: 12,
                        height: 12,
                        backgroundColor: "#fff",
                        borderRadius: 2,
                      }}
                    />
                  )}
                </TouchableOpacity>
                <Text style={{ marginLeft: 8, color: "#374151" }}>
                  Follow-up needed
                </Text>
              </View>

              {interactionData.follow_up_needed && (
                <View style={{ marginTop: 15 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      marginBottom: 8,
                      color: "#374151",
                    }}
                  >
                    Follow-up Date
                  </Text>
                  <TextInput
                    style={{
                      borderWidth: 1,
                      borderColor: "#D1D5DB",
                      borderRadius: 8,
                      padding: 12,
                      fontSize: 16,
                      backgroundColor: "#fff",
                    }}
                    placeholder="YYYY-MM-DD"
                    value={interactionData.follow_up_date}
                    onChangeText={(text) =>
                      setInteractionData({
                        ...interactionData,
                        follow_up_date: text,
                      })
                    }
                  />
                </View>
              )}
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: "#16A34A",
                paddingVertical: 15,
                borderRadius: 8,
                alignItems: "center",
                marginTop: 20,
              }}
              onPress={addInteraction}
            >
              <Text style={{ color: "#fff", fontWeight: "600", fontSize: 16 }}>
                Add Interaction
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}
