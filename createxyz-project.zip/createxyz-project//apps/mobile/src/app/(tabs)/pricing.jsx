import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Picker } from "@react-native-picker/picker";
import { Calculator, DollarSign, MapPin } from "lucide-react-native";
import { useLocalSearchParams } from "expo-router";

export default function PricingScreen() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const [serviceTypes, setServiceTypes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [calculating, setCalculating] = useState(false);

  // Form state
  const [selectedService, setSelectedService] = useState("");
  const [propertySizeSqft, setPropertySizeSqft] = useState("");
  const [terrainDifficulty, setTerrainDifficulty] = useState("flat");
  const [zipCode, setZipCode] = useState("");
  const [customLaborRate, setCustomLaborRate] = useState("");
  const [customProfitMargin, setCustomProfitMargin] = useState("");
  const [additionalMaterials, setAdditionalMaterials] = useState("");

  // Results state
  const [pricingResult, setPricingResult] = useState(null);

  useEffect(() => {
    fetchServiceTypes();
  }, []);

  useEffect(() => {
    // Handle parameters from pest identification
    if (params.serviceType === "pest_treatment" && serviceTypes.length > 0) {
      // Find the pest treatment service type
      const pestService = serviceTypes.find(
        (s) =>
          s.name.toLowerCase().includes("pest") ||
          s.name.toLowerCase().includes("treatment"),
      );
      if (pestService) {
        setSelectedService(pestService.id);

        // Show notification about pre-filled data
        Alert.alert(
          "Pest Treatment Details",
          `The form has been pre-filled with the pest treatment service and estimated materials cost for treating ${params.pestName}. Please enter your property size to calculate the final price.`,
          [{ text: "OK" }],
        );
      }

      // If we have an estimated cost from the pest analysis, set it as additional materials
      if (params.estimatedCost) {
        const cost = params.estimatedCost.match(/\$(\d+)/);
        if (cost && cost[1]) {
          setAdditionalMaterials(cost[1]);
        }
      }
    }
  }, [params, serviceTypes]);

  const fetchServiceTypes = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/service-types");
      if (!response.ok) throw new Error("Failed to fetch service types");
      const data = await response.json();
      setServiceTypes(data);
    } catch (error) {
      console.error("Error fetching service types:", error);
      Alert.alert("Error", "Failed to load service types");
    } finally {
      setLoading(false);
    }
  };

  const calculatePricing = async () => {
    if (!selectedService || !propertySizeSqft) {
      Alert.alert(
        "Error",
        "Please select a service type and enter property size",
      );
      return;
    }

    try {
      setCalculating(true);
      const response = await fetch("/api/pricing/calculate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          serviceTypeId: selectedService,
          propertySizeSqft: parseInt(propertySizeSqft),
          terrainDifficulty,
          zipCode: zipCode || null,
          customLaborRate: customLaborRate ? parseFloat(customLaborRate) : null,
          customProfitMargin: customProfitMargin
            ? parseFloat(customProfitMargin)
            : null,
          additionalMaterials: additionalMaterials
            ? parseFloat(additionalMaterials)
            : 0,
        }),
      });

      if (!response.ok) throw new Error("Failed to calculate pricing");
      const data = await response.json();
      setPricingResult(data);
    } catch (error) {
      console.error("Error calculating pricing:", error);
      Alert.alert("Error", "Failed to calculate pricing");
    } finally {
      setCalculating(false);
    }
  };

  const resetForm = () => {
    setSelectedService("");
    setPropertySizeSqft("");
    setTerrainDifficulty("flat");
    setZipCode("");
    setCustomLaborRate("");
    setCustomProfitMargin("");
    setAdditionalMaterials("");
    setPricingResult(null);
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <ActivityIndicator size="large" color="#16A34A" />
        <Text style={{ marginTop: 10, color: "#6B7280" }}>
          Loading service types...
        </Text>
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#16A34A",
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Calculator color="#fff" size={24} />
          <Text
            style={{
              color: "#fff",
              fontSize: 24,
              fontWeight: "bold",
              marginLeft: 10,
            }}
          >
            Pricing Calculator
          </Text>
        </View>
        <Text style={{ color: "#E5F3E5", marginTop: 5 }}>
          Calculate accurate pricing for your lawn care services
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Service Selection */}
        <View
          style={{
            backgroundColor: "#fff",
            margin: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 15,
              color: "#111827",
            }}
          >
            Service Details
          </Text>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Service Type *
          </Text>
          <View
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              marginBottom: 15,
            }}
          >
            <Picker
              selectedValue={selectedService}
              onValueChange={setSelectedService}
              style={{ height: 50 }}
            >
              <Picker.Item label="Select a service..." value="" />
              {serviceTypes.map((service) => (
                <Picker.Item
                  key={service.id}
                  label={service.name}
                  value={service.id}
                />
              ))}
            </Picker>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Property Size (sq ft) *
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="e.g. 5000"
            value={propertySizeSqft}
            onChangeText={setPropertySizeSqft}
            keyboardType="numeric"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Terrain Difficulty
          </Text>
          <View
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              marginBottom: 15,
            }}
          >
            <Picker
              selectedValue={terrainDifficulty}
              onValueChange={setTerrainDifficulty}
              style={{ height: 50 }}
            >
              <Picker.Item label="Flat" value="flat" />
              <Picker.Item label="Slight Slope" value="slight_slope" />
              <Picker.Item label="Steep Slope" value="steep_slope" />
              <Picker.Item label="Obstacles" value="obstacles" />
              <Picker.Item label="Difficult Access" value="difficult_access" />
            </Picker>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Zip Code (for regional pricing)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="e.g. 12345"
            value={zipCode}
            onChangeText={setZipCode}
            keyboardType="numeric"
            maxLength={5}
          />
        </View>

        {/* Advanced Options */}
        <View
          style={{
            backgroundColor: "#fff",
            marginHorizontal: 20,
            marginBottom: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 15,
              color: "#111827",
            }}
          >
            Advanced Options
          </Text>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Custom Labor Rate ($/hour)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="Leave blank for default"
            value={customLaborRate}
            onChangeText={setCustomLaborRate}
            keyboardType="numeric"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Custom Profit Margin (%)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="Leave blank for default (25%)"
            value={customProfitMargin}
            onChangeText={setCustomProfitMargin}
            keyboardType="numeric"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Additional Materials Cost ($)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="0"
            value={additionalMaterials}
            onChangeText={setAdditionalMaterials}
            keyboardType="numeric"
          />
        </View>

        {/* Action Buttons */}
        <View
          style={{
            flexDirection: "row",
            marginHorizontal: 20,
            marginBottom: 20,
            gap: 10,
          }}
        >
          <TouchableOpacity
            style={{
              flex: 1,
              backgroundColor: "#16A34A",
              paddingVertical: 15,
              borderRadius: 8,
              alignItems: "center",
              opacity: calculating ? 0.7 : 1,
            }}
            onPress={calculatePricing}
            disabled={calculating}
          >
            {calculating ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <DollarSign color="#fff" size={20} />
                <Text
                  style={{ color: "#fff", fontWeight: "600", marginTop: 5 }}
                >
                  Calculate Price
                </Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              backgroundColor: "#6B7280",
              paddingVertical: 15,
              paddingHorizontal: 20,
              borderRadius: 8,
              alignItems: "center",
            }}
            onPress={resetForm}
          >
            <Text style={{ color: "#fff", fontWeight: "600" }}>Reset</Text>
          </TouchableOpacity>
        </View>

        {/* Results */}
        {pricingResult && (
          <View
            style={{
              backgroundColor: "#fff",
              marginHorizontal: 20,
              marginBottom: 20,
              borderRadius: 12,
              padding: 20,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
            }}
          >
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginBottom: 15,
                color: "#111827",
              }}
            >
              Pricing Results - {pricingResult.serviceName}
            </Text>

            <View
              style={{
                backgroundColor: "#16A34A",
                padding: 15,
                borderRadius: 8,
                marginBottom: 15,
              }}
            >
              <Text style={{ color: "#fff", fontSize: 16, fontWeight: "500" }}>
                Suggested Quote
              </Text>
              <Text style={{ color: "#fff", fontSize: 32, fontWeight: "bold" }}>
                ${pricingResult.recommendations.suggestedQuote}
              </Text>
              <Text style={{ color: "#E5F3E5", fontSize: 14 }}>
                Competitive range: $
                {pricingResult.recommendations.competitiveRange.low} - $
                {pricingResult.recommendations.competitiveRange.high}
              </Text>
            </View>

            {/* Calculation Formula */}
            <View
              style={{
                backgroundColor: "#F3F4F6",
                padding: 15,
                borderRadius: 8,
                marginBottom: 15,
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  marginBottom: 8,
                  color: "#111827",
                }}
              >
                Calculation Method
              </Text>
              <Text style={{ color: "#374151", fontSize: 14, marginBottom: 8 }}>
                {pricingResult.calculation.formula}
              </Text>
              <Text style={{ color: "#6B7280", fontSize: 12 }}>
                Property size: {pricingResult.propertySize.toLocaleString()} sq
                ft
              </Text>
            </View>

            <View style={{ marginBottom: 15 }}>
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  marginBottom: 10,
                  color: "#111827",
                }}
              >
                Price Breakdown
              </Text>

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginBottom: 5,
                }}
              >
                <Text style={{ color: "#6B7280" }}>Base Price</Text>
                <Text style={{ color: "#111827", fontWeight: "500" }}>
                  ${pricingResult.breakdown.basePrice}
                </Text>
              </View>

              {pricingResult.breakdown.regionalMultiplier !== 1.0 && (
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    marginBottom: 5,
                  }}
                >
                  <Text style={{ color: "#6B7280" }}>
                    Regional Adjustment (
                    {pricingResult.breakdown.regionalMultiplier}x)
                  </Text>
                  <Text style={{ color: "#111827", fontWeight: "500" }}>
                    ${pricingResult.breakdown.adjustedPrice}
                  </Text>
                </View>
              )}

              {pricingResult.breakdown.terrainMultiplier !== 1.0 && (
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    marginBottom: 5,
                  }}
                >
                  <Text style={{ color: "#6B7280" }}>
                    Terrain Adjustment (
                    {pricingResult.breakdown.terrainMultiplier}x)
                  </Text>
                  <Text style={{ color: "#111827", fontWeight: "500" }}>
                    ${pricingResult.breakdown.adjustedPrice}
                  </Text>
                </View>
              )}

              {pricingResult.breakdown.additionalMaterials > 0 && (
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    marginBottom: 5,
                  }}
                >
                  <Text style={{ color: "#6B7280" }}>Additional Materials</Text>
                  <Text style={{ color: "#111827", fontWeight: "500" }}>
                    ${pricingResult.breakdown.additionalMaterials}
                  </Text>
                </View>
              )}

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginBottom: 5,
                  paddingTop: 5,
                  borderTopWidth: 1,
                  borderTopColor: "#E5E7EB",
                }}
              >
                <Text style={{ color: "#6B7280" }}>Subtotal</Text>
                <Text style={{ color: "#111827", fontWeight: "500" }}>
                  ${pricingResult.breakdown.totalMaterialCost}
                </Text>
              </View>

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  marginBottom: 5,
                }}
              >
                <Text style={{ color: "#6B7280" }}>
                  Profit ({pricingResult.breakdown.profitMargin}%)
                </Text>
                <Text style={{ color: "#16A34A", fontWeight: "600" }}>
                  ${pricingResult.breakdown.profitAmount}
                </Text>
              </View>

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  paddingTop: 5,
                  borderTopWidth: 2,
                  borderTopColor: "#16A34A",
                }}
              >
                <Text
                  style={{ color: "#111827", fontWeight: "600", fontSize: 16 }}
                >
                  Final Price
                </Text>
                <Text
                  style={{ color: "#16A34A", fontWeight: "bold", fontSize: 16 }}
                >
                  ${pricingResult.breakdown.finalPrice}
                </Text>
              </View>
            </View>

            <View
              style={{
                backgroundColor: "#F3F4F6",
                padding: 10,
                borderRadius: 6,
              }}
            >
              <Text style={{ fontSize: 12, color: "#6B7280" }}>
                Price per sq ft: ${pricingResult.breakdown.pricePerSqft} •
                Minimum coverage:{" "}
                {pricingResult.breakdown.minimumCoverage.toLocaleString()} sq ft
                • Rate: ${pricingResult.breakdown.pricePerThousand}/1000sqft
              </Text>
            </View>
          </View>
        )}
      </ScrollView>
    </View>
  );
}
