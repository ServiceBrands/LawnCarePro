import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Modal,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  Settings as SettingsIcon,
  Building,
  DollarSign,
  Percent,
  Save,
  Edit,
  Calculator,
} from "lucide-react-native";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [serviceTypes, setServiceTypes] = useState([]);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [editingService, setEditingService] = useState(null);

  // Business settings form state
  const [businessSettings, setBusinessSettings] = useState({
    business_name: "",
    owner_name: "",
    phone: "",
    email: "",
    address: "",
    license_number: "",
    insurance_cost_monthly: "",
    fuel_cost_per_gallon: "",
    default_profit_margin: "",
    hourly_labor_rate: "",
  });

  // Service pricing form state
  const [serviceForm, setServiceForm] = useState({
    name: "",
    minimum_price: "",
    minimum_coverage_sqft: "3000",
    price_per_1000sqft: "",
    description: "",
  });

  useEffect(() => {
    fetchBusinessSettings();
    fetchServiceTypes();
  }, []);

  const fetchServiceTypes = async () => {
    try {
      const response = await fetch("/api/service-types");
      if (!response.ok) throw new Error("Failed to fetch service types");
      const data = await response.json();
      setServiceTypes(data);
    } catch (error) {
      console.error("Error fetching service types:", error);
      Alert.alert("Error", "Failed to load service types");
    }
  };

  const openServiceModal = (service = null) => {
    if (service) {
      setServiceForm({
        name: service.name || "",
        minimum_price: service.minimum_price?.toString() || "",
        minimum_coverage_sqft:
          service.minimum_coverage_sqft?.toString() || "3000",
        price_per_1000sqft: service.price_per_1000sqft?.toString() || "",
        description: service.description || "",
      });
      setEditingService(service);
    } else {
      setServiceForm({
        name: "",
        minimum_price: "",
        minimum_coverage_sqft: "3000",
        price_per_1000sqft: "",
        description: "",
      });
      setEditingService(null);
    }
    setShowServiceModal(true);
  };

  const closeServiceModal = () => {
    setShowServiceModal(false);
    setEditingService(null);
    setServiceForm({
      name: "",
      minimum_price: "",
      minimum_coverage_sqft: "3000",
      price_per_1000sqft: "",
      description: "",
    });
  };

  const saveServicePricing = async () => {
    if (
      !serviceForm.name ||
      !serviceForm.minimum_price ||
      !serviceForm.price_per_1000sqft
    ) {
      Alert.alert("Error", "Please fill in all required fields");
      return;
    }

    try {
      const url = "/api/service-types";
      const method = editingService ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...(editingService && { id: editingService.id }),
          name: serviceForm.name,
          minimum_price: parseFloat(serviceForm.minimum_price),
          minimum_coverage_sqft: parseInt(serviceForm.minimum_coverage_sqft),
          price_per_1000sqft: parseFloat(serviceForm.price_per_1000sqft),
          description: serviceForm.description,
        }),
      });

      if (!response.ok) throw new Error("Failed to save service pricing");

      closeServiceModal();
      fetchServiceTypes();
      Alert.alert(
        "Success",
        `Service pricing ${editingService ? "updated" : "created"} successfully`,
      );
    } catch (error) {
      console.error("Error saving service pricing:", error);
      Alert.alert("Error", "Failed to save service pricing");
    }
  };

  const fetchBusinessSettings = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/business-settings");
      if (!response.ok) throw new Error("Failed to fetch business settings");
      const data = await response.json();

      if (data.length > 0) {
        const settings = data[0];
        setBusinessSettings({
          business_name: settings.business_name || "",
          owner_name: settings.owner_name || "",
          phone: settings.phone || "",
          email: settings.email || "",
          address: settings.address || "",
          license_number: settings.license_number || "",
          insurance_cost_monthly:
            settings.insurance_cost_monthly?.toString() || "",
          fuel_cost_per_gallon: settings.fuel_cost_per_gallon?.toString() || "",
          default_profit_margin:
            settings.default_profit_margin?.toString() || "",
          hourly_labor_rate: settings.hourly_labor_rate?.toString() || "",
        });
      }
    } catch (error) {
      console.error("Error fetching business settings:", error);
      Alert.alert("Error", "Failed to load business settings");
    } finally {
      setLoading(false);
    }
  };

  const saveBusinessSettings = async () => {
    try {
      setSaving(true);

      const response = await fetch("/api/business-settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...businessSettings,
          insurance_cost_monthly: businessSettings.insurance_cost_monthly
            ? parseFloat(businessSettings.insurance_cost_monthly)
            : null,
          fuel_cost_per_gallon: businessSettings.fuel_cost_per_gallon
            ? parseFloat(businessSettings.fuel_cost_per_gallon)
            : null,
          default_profit_margin: businessSettings.default_profit_margin
            ? parseFloat(businessSettings.default_profit_margin)
            : null,
          hourly_labor_rate: businessSettings.hourly_labor_rate
            ? parseFloat(businessSettings.hourly_labor_rate)
            : null,
        }),
      });

      if (!response.ok) throw new Error("Failed to save business settings");

      Alert.alert("Success", "Business settings saved successfully");
    } catch (error) {
      console.error("Error saving business settings:", error);
      Alert.alert("Error", "Failed to save business settings");
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key, value) => {
    setBusinessSettings((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          justifyContent: "center",
          alignItems: "center",
          paddingTop: insets.top,
        }}
      >
        <ActivityIndicator size="large" color="#16A34A" />
        <Text style={{ marginTop: 10, color: "#6B7280" }}>
          Loading settings...
        </Text>
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          backgroundColor: "#16A34A",
          paddingHorizontal: 20,
          paddingVertical: 20,
          borderBottomLeftRadius: 20,
          borderBottomRightRadius: 20,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <SettingsIcon color="#fff" size={24} />
          <Text
            style={{
              color: "#fff",
              fontSize: 24,
              fontWeight: "bold",
              marginLeft: 10,
            }}
          >
            Settings
          </Text>
        </View>
        <Text style={{ color: "#E5F3E5", marginTop: 5 }}>
          Configure your business settings and pricing defaults
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Business Information */}
        <View
          style={{
            backgroundColor: "#fff",
            margin: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 15,
            }}
          >
            <Building color="#16A34A" size={20} />
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginLeft: 8,
                color: "#111827",
              }}
            >
              Business Information
            </Text>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Business Name
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="Your Lawn Care Business"
            value={businessSettings.business_name}
            onChangeText={(text) => updateSetting("business_name", text)}
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Owner Name
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="John Smith"
            value={businessSettings.owner_name}
            onChangeText={(text) => updateSetting("owner_name", text)}
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Phone Number
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="(555) 123-4567"
            value={businessSettings.phone}
            onChangeText={(text) => updateSetting("phone", text)}
            keyboardType="phone-pad"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Email Address
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="contact@yourbusiness.com"
            value={businessSettings.email}
            onChangeText={(text) => updateSetting("email", text)}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Business Address
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
              height: 80,
              textAlignVertical: "top",
            }}
            placeholder="123 Main St, City, State 12345"
            value={businessSettings.address}
            onChangeText={(text) => updateSetting("address", text)}
            multiline
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            License Number
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="LIC123456"
            value={businessSettings.license_number}
            onChangeText={(text) => updateSetting("license_number", text)}
          />
        </View>

        {/* Pricing Defaults */}
        <View
          style={{
            backgroundColor: "#fff",
            marginHorizontal: 20,
            marginBottom: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 15,
            }}
          >
            <DollarSign color="#16A34A" size={20} />
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginLeft: 8,
                color: "#111827",
              }}
            >
              Pricing Defaults
            </Text>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Hourly Labor Rate ($)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="35.00"
            value={businessSettings.hourly_labor_rate}
            onChangeText={(text) => updateSetting("hourly_labor_rate", text)}
            keyboardType="numeric"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Default Profit Margin (%)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="25.0"
            value={businessSettings.default_profit_margin}
            onChangeText={(text) =>
              updateSetting("default_profit_margin", text)
            }
            keyboardType="numeric"
          />

          <View
            style={{
              backgroundColor: "#EFF6FF",
              padding: 12,
              borderRadius: 6,
              marginBottom: 15,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <Percent color="#1E40AF" size={16} />
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "600",
                  marginLeft: 6,
                  color: "#1E40AF",
                }}
              >
                Profit Margin Guidelines
              </Text>
            </View>
            <Text style={{ color: "#1E40AF", fontSize: 12, lineHeight: 16 }}>
              • Basic services: 15-25%{"\n"}• Specialized services: 25-35%{"\n"}
              • Premium services: 35-50%
            </Text>
          </View>
        </View>

        {/* Operating Costs */}
        <View
          style={{
            backgroundColor: "#fff",
            marginHorizontal: 20,
            marginBottom: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 15,
            }}
          >
            <SettingsIcon color="#16A34A" size={20} />
            <Text
              style={{
                fontSize: 18,
                fontWeight: "600",
                marginLeft: 8,
                color: "#111827",
              }}
            >
              Operating Costs
            </Text>
          </View>

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Monthly Insurance Cost ($)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="250.00"
            value={businessSettings.insurance_cost_monthly}
            onChangeText={(text) =>
              updateSetting("insurance_cost_monthly", text)
            }
            keyboardType="numeric"
          />

          <Text
            style={{
              fontSize: 14,
              fontWeight: "500",
              marginBottom: 8,
              color: "#374151",
            }}
          >
            Fuel Cost per Gallon ($)
          </Text>
          <TextInput
            style={{
              borderWidth: 1,
              borderColor: "#D1D5DB",
              borderRadius: 8,
              padding: 12,
              fontSize: 16,
              marginBottom: 15,
              backgroundColor: "#fff",
            }}
            placeholder="3.50"
            value={businessSettings.fuel_cost_per_gallon}
            onChangeText={(text) => updateSetting("fuel_cost_per_gallon", text)}
            keyboardType="numeric"
          />

          <View
            style={{
              backgroundColor: "#FEF3C7",
              padding: 12,
              borderRadius: 6,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontWeight: "600",
                marginBottom: 5,
                color: "#92400E",
              }}
            >
              💡 Cost Tracking Tips
            </Text>
            <Text style={{ color: "#92400E", fontSize: 12, lineHeight: 16 }}>
              • Update fuel costs regularly for accurate pricing{"\n"}• Include
              equipment maintenance in overhead calculations{"\n"}• Review
              insurance costs annually
            </Text>
          </View>
        </View>

        {/* Service Pricing Configuration */}
        <View
          style={{
            backgroundColor: "#fff",
            marginHorizontal: 20,
            marginBottom: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: 15,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Calculator color="#16A34A" size={20} />
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginLeft: 8,
                  color: "#111827",
                }}
              >
                Service Pricing
              </Text>
            </View>
            <TouchableOpacity
              style={{
                backgroundColor: "#16A34A",
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 6,
              }}
              onPress={() => openServiceModal()}
            >
              <Text style={{ color: "#fff", fontSize: 12, fontWeight: "600" }}>
                Add Service
              </Text>
            </TouchableOpacity>
          </View>

          <Text style={{ color: "#6B7280", marginBottom: 15, fontSize: 14 }}>
            Configure your per-1000-sqft pricing for each service type
          </Text>

          {serviceTypes.length === 0 ? (
            <View style={{ alignItems: "center", paddingVertical: 20 }}>
              <Calculator color="#6B7280" size={32} />
              <Text
                style={{ color: "#6B7280", marginTop: 10, textAlign: "center" }}
              >
                No service pricing configured yet.{"\n"}Add your first service
                to get started.
              </Text>
            </View>
          ) : (
            serviceTypes.map((service) => (
              <View
                key={service.id}
                style={{
                  backgroundColor: "#F9FAFB",
                  padding: 15,
                  borderRadius: 8,
                  marginBottom: 10,
                  borderLeftWidth: 4,
                  borderLeftColor: "#16A34A",
                }}
              >
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "600",
                        color: "#111827",
                        marginBottom: 5,
                      }}
                    >
                      {service.name}
                    </Text>
                    <Text
                      style={{
                        color: "#6B7280",
                        fontSize: 14,
                        marginBottom: 8,
                      }}
                    >
                      {service.description}
                    </Text>
                    <View
                      style={{
                        flexDirection: "row",
                        flexWrap: "wrap",
                        gap: 10,
                      }}
                    >
                      <View
                        style={{
                          backgroundColor: "#fff",
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 4,
                        }}
                      >
                        <Text style={{ fontSize: 12, color: "#374151" }}>
                          Min: ${service.minimum_price}
                        </Text>
                      </View>
                      <View
                        style={{
                          backgroundColor: "#fff",
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 4,
                        }}
                      >
                        <Text style={{ fontSize: 12, color: "#374151" }}>
                          Covers:{" "}
                          {service.minimum_coverage_sqft?.toLocaleString()} sqft
                        </Text>
                      </View>
                      <View
                        style={{
                          backgroundColor: "#fff",
                          paddingHorizontal: 8,
                          paddingVertical: 4,
                          borderRadius: 4,
                        }}
                      >
                        <Text style={{ fontSize: 12, color: "#374151" }}>
                          ${service.price_per_1000sqft}/1000sqft
                        </Text>
                      </View>
                    </View>
                  </View>
                  <TouchableOpacity
                    style={{
                      backgroundColor: "#F3F4F6",
                      padding: 8,
                      borderRadius: 6,
                      marginLeft: 10,
                    }}
                    onPress={() => openServiceModal(service)}
                  >
                    <Edit color="#6B7280" size={16} />
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}

          <View
            style={{
              backgroundColor: "#EFF6FF",
              padding: 12,
              borderRadius: 6,
              marginTop: 10,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontWeight: "600",
                marginBottom: 5,
                color: "#1E40AF",
              }}
            >
              💡 Pricing Model
            </Text>
            <Text style={{ color: "#1E40AF", fontSize: 12, lineHeight: 16 }}>
              • Minimum price covers the first{" "}
              {serviceTypes[0]?.minimum_coverage_sqft || 3000} sq ft{"\n"}•
              Additional area charged per 1000 sq ft{"\n"}• Example: 5000 sqft =
              Minimum + (2000 ÷ 1000) × Rate
            </Text>
          </View>
        </View>

        {/* Save Button */}
        <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
          <TouchableOpacity
            style={{
              backgroundColor: "#16A34A",
              paddingVertical: 15,
              borderRadius: 8,
              alignItems: "center",
              flexDirection: "row",
              justifyContent: "center",
              opacity: saving ? 0.7 : 1,
            }}
            onPress={saveBusinessSettings}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Save color="#fff" size={20} />
                <Text
                  style={{
                    color: "#fff",
                    fontWeight: "600",
                    marginLeft: 8,
                    fontSize: 16,
                  }}
                >
                  Save Settings
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>

        {/* App Information */}
        <View
          style={{
            backgroundColor: "#fff",
            marginHorizontal: 20,
            marginBottom: 20,
            borderRadius: 12,
            padding: 20,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.1,
            shadowRadius: 4,
            elevation: 3,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              marginBottom: 15,
              color: "#111827",
            }}
          >
            About Lawn Care Pro
          </Text>

          <Text style={{ color: "#6B7280", marginBottom: 10, lineHeight: 20 }}>
            Version 1.0.0
          </Text>

          <Text style={{ color: "#6B7280", lineHeight: 20 }}>
            A comprehensive pricing and pest identification app designed
            specifically for lawn care and landscaping business owners.
          </Text>

          <View
            style={{
              backgroundColor: "#F3F4F6",
              padding: 12,
              borderRadius: 6,
              marginTop: 15,
            }}
          >
            <Text
              style={{
                fontSize: 14,
                fontWeight: "600",
                marginBottom: 5,
                color: "#374151",
              }}
            >
              🌱 Features
            </Text>
            <Text style={{ color: "#6B7280", fontSize: 12, lineHeight: 16 }}>
              • AI-powered pest and weed identification{"\n"}• Comprehensive
              pricing calculator{"\n"}• Customer database management{"\n"}•
              Regional pricing adjustments{"\n"}• Professional quote generation
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Service Pricing Modal */}
      <Modal
        visible={showServiceModal}
        animationType="slide"
        presentationStyle="pageSheet"
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "#F9FAFB",
            paddingTop: insets.top,
          }}
        >
          {/* Modal Header */}
          <View
            style={{
              backgroundColor: "#16A34A",
              paddingHorizontal: 20,
              paddingVertical: 20,
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text
                style={{
                  color: "#fff",
                  fontSize: 20,
                  fontWeight: "bold",
                }}
              >
                {editingService
                  ? "Edit Service Pricing"
                  : "Add Service Pricing"}
              </Text>
              <TouchableOpacity onPress={closeServiceModal}>
                <Text style={{ color: "#fff", fontSize: 16 }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>

          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
            showsVerticalScrollIndicator={false}
          >
            {/* Service Information */}
            <View
              style={{
                backgroundColor: "#fff",
                margin: 20,
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 15,
                  color: "#111827",
                }}
              >
                Service Information
              </Text>

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Service Name *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="e.g. Fertilizing, Weed Control"
                value={serviceForm.name}
                onChangeText={(text) =>
                  setServiceForm({ ...serviceForm, name: text })
                }
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Description
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                  height: 80,
                  textAlignVertical: "top",
                }}
                placeholder="Brief description of the service"
                value={serviceForm.description}
                onChangeText={(text) =>
                  setServiceForm({ ...serviceForm, description: text })
                }
                multiline
              />
            </View>

            {/* Pricing Configuration */}
            <View
              style={{
                backgroundColor: "#fff",
                marginHorizontal: 20,
                marginBottom: 20,
                borderRadius: 12,
                padding: 20,
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
                elevation: 3,
              }}
            >
              <Text
                style={{
                  fontSize: 18,
                  fontWeight: "600",
                  marginBottom: 15,
                  color: "#111827",
                }}
              >
                Pricing Configuration
              </Text>

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Minimum Starting Price ($) *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="75.00"
                value={serviceForm.minimum_price}
                onChangeText={(text) =>
                  setServiceForm({ ...serviceForm, minimum_price: text })
                }
                keyboardType="numeric"
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Minimum Coverage (sq ft)
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="3000"
                value={serviceForm.minimum_coverage_sqft}
                onChangeText={(text) =>
                  setServiceForm({
                    ...serviceForm,
                    minimum_coverage_sqft: text,
                  })
                }
                keyboardType="numeric"
              />

              <Text
                style={{
                  fontSize: 14,
                  fontWeight: "500",
                  marginBottom: 8,
                  color: "#374151",
                }}
              >
                Price per 1000 sq ft ($) *
              </Text>
              <TextInput
                style={{
                  borderWidth: 1,
                  borderColor: "#D1D5DB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 16,
                  marginBottom: 15,
                  backgroundColor: "#fff",
                }}
                placeholder="25.00"
                value={serviceForm.price_per_1000sqft}
                onChangeText={(text) =>
                  setServiceForm({ ...serviceForm, price_per_1000sqft: text })
                }
                keyboardType="numeric"
              />

              <View
                style={{
                  backgroundColor: "#F0FDF4",
                  padding: 12,
                  borderRadius: 6,
                  borderLeftWidth: 4,
                  borderLeftColor: "#16A34A",
                }}
              >
                <Text
                  style={{
                    fontSize: 14,
                    fontWeight: "600",
                    marginBottom: 5,
                    color: "#15803D",
                  }}
                >
                  💡 Pricing Example
                </Text>
                <Text
                  style={{ color: "#15803D", fontSize: 12, lineHeight: 16 }}
                >
                  {serviceForm.minimum_price &&
                  serviceForm.minimum_coverage_sqft &&
                  serviceForm.price_per_1000sqft
                    ? `For a 5,000 sq ft property:\n` +
                      `• Minimum: $${serviceForm.minimum_price} (covers first ${serviceForm.minimum_coverage_sqft} sq ft)\n` +
                      `• Additional: ${Math.max(0, (5000 - parseInt(serviceForm.minimum_coverage_sqft || 0)) / 1000).toFixed(1)} × $${serviceForm.price_per_1000sqft} = $${(Math.max(0, (5000 - parseInt(serviceForm.minimum_coverage_sqft || 0)) / 1000) * parseFloat(serviceForm.price_per_1000sqft || 0)).toFixed(2)}\n` +
                      `• Total: $${(parseFloat(serviceForm.minimum_price || 0) + Math.max(0, (5000 - parseInt(serviceForm.minimum_coverage_sqft || 0)) / 1000) * parseFloat(serviceForm.price_per_1000sqft || 0)).toFixed(2)}`
                    : "Fill in the pricing fields above to see an example calculation"}
                </Text>
              </View>
            </View>

            {/* Save Button */}
            <View style={{ marginHorizontal: 20, marginBottom: 20 }}>
              <TouchableOpacity
                style={{
                  backgroundColor: "#16A34A",
                  paddingVertical: 15,
                  borderRadius: 8,
                  alignItems: "center",
                }}
                onPress={saveServicePricing}
              >
                <Text
                  style={{ color: "#fff", fontWeight: "600", fontSize: 16 }}
                >
                  {editingService ? "Update Service" : "Add Service"}
                </Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}
